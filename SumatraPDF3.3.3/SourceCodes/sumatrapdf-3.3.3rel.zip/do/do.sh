#!/bin/bash

cd do
go run . $@