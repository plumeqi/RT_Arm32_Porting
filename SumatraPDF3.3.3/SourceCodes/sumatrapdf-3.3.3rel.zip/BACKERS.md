<h1 align="center">Sponsors &amp; Backers</h1>

SumatraPDF is a free, open source project. Consider supporting it so that I can improve it in the future:

- [become a backer or sponsor on Patreon](https://www.patreon.com/sumatrapdf).
- [one-time donation via PayPal](https://www.paypal.me/sumatrapdf)

A few words on Patreon membership levels.

If you're an individual who wants to support development of SumatraPDF, join $3/month level.

If you're a company that benefits from SumatraPDF (e.g. you use SumatraPDF in your company or ship SumatraPDF as part of your software), join $50/month Corporate Sponsor.

For $500/month you can become Platinum Sponsor. Support SumatraPDF and advertise your company. A link to your company will be put on SumatraPDF [home page](https://www.sumatrapdfreader.org/) as well as on start screen of SumatraPDF (starting with next version 3.3). This could be worth more than you're paying for.

<h2 align="center">Backers via Patreon</h2>

### Corporate Sponsors

- Sellintegro sp. z o.o. (https://sellintegro.com)

### Personal Sponsors

- Reinhold Thurner
- Aazmandius
- Linfeng Li
- Hayashi Takehito
- Mihai Dragan
- hldingyetian
- David Walluscheck
- Roger Bratseth
- Victor Soli
- Laurent NOEL
- Nikita
- Walter Manbeck
- Curtis Y Takahashi
- Hasan Kamal-Al-Deen
- Christian Schulz
- Jim Vanderbilt
- Tobias Widmann
- shorlee
- Tony
- Mikhail Smirnov
- TRboom
- Karl Vyzard
- Brian Bradley
- Steven Bickle
- Ahsan Rauf
- Mark
