#pragma once

#define VERSION_HASH _T("62db550")
#define VERSION_REV 998
#define VERSION_REV_FULL _T("998 (62db550)")
