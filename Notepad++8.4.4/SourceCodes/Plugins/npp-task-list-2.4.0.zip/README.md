# npp-task-list

Fixed performance problems.

## Note :
To compile this plugin you will need Visual Studio 2017 or newer.
Here a link to the download : [VS-2019 CE EN_us](https://download.visualstudio.microsoft.com/download/pr/9b3476ff-6d0a-4ff8-956d-270147f21cd4/76e39c746d9e2fc3eadd003b5b11440bcf926f3948fb2df14d5938a1a8b2b32f/vs_Community.exe)

