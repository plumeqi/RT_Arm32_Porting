//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TaskList.rc
//
#ifndef RESOURCE_H
    #define RESOURCE_H

    #define IDC_STATIC  -1

    #define IDD_ABOUT_DIALOG        100
    #define IDC_ABOUT_URL_PREFIX    101
    #define IDC_ABOUT_URL           102
    #define IDC_ABOUT_TITLE         103
    #define IDC_ABOUT_CONTRIBUTORS  110
    #define IDC_ABOUT_CONTRIBUTOR1  111
    #define IDC_ABOUT_CONTRIBUTOR2  112
    #define IDC_ABOUT_CONTRIBUTOR3  113
    #define IDC_ABOUT_CONTRIBUTOR4  114

    #define IDD_TODOLIST_DIALOG 200
    #define ID_GOLINE_EDIT      201
    #define ID_UGO_STATIC       205
    #define ID_TODO_LIST        210
#endif // RESOURCE_H
