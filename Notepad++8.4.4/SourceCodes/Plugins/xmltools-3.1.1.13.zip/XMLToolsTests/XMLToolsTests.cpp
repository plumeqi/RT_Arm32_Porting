#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace XMLToolsTests {
	TEST_CLASS(XMLToolsTests) {
	public:
		TEST_METHOD(XMLToolsTest1) {
		}
	};
}
