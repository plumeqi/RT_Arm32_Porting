#include "stdAfx.h"

#include "XMLTools.h"
#include "Scintilla.h"
#include "nppHelpers.h"

void closeXMLTag() {
    dbgln("closeXMLTag()");

    char buf[512];
    int currentEdit;
    ::SendMessage(nppData._nppHandle, NPPM_GETCURRENTSCINTILLA, 0, (LPARAM)&currentEdit);
    HWND hCurrentEditView = getCurrentHScintilla(currentEdit);
    Sci_PositionCR currentPos = Sci_PositionCR(::SendMessage(hCurrentEditView, SCI_GETCURRENTPOS, 0, 0));
    Sci_PositionCR beginPos = currentPos - (sizeof(buf) - 1);
    Sci_PositionCR startPos = (beginPos > 0) ? beginPos : 0;
    Sci_PositionCR size = currentPos - startPos;
    //int insertStringSize = 2;

#define MAX_TAGNAME_LENGTH 516
    char insertString[MAX_TAGNAME_LENGTH] = "</";

    if (size >= 3) {
        struct TextRange tr = { {startPos, currentPos}, buf };
        ::SendMessage(hCurrentEditView, SCI_GETTEXTRANGE, 0, (LPARAM)&tr);

        if (buf[size - 2] != '/' && buf[size - 2] != '-' && buf[size - 2] != '?' && buf[size - 2] != ']' && buf[size - 2] != ')' && buf[size - 2] != '%') {
            const char* pBegin = &buf[0];
            const char* pCur = &buf[size - 2];
            int insertStringSize = 2;

            // search the beginning of tag
            // TODO: optimize by not looping on every char !
            for (; pCur > pBegin && *pCur != '<' && *pCur != '>';) {
                --pCur;
            }

            if (*pCur == '<') {
                ++pCur;
                if (*pCur == '/' || *pCur == '!' || *pCur == '?' || *pCur == '[' || *pCur == '%') return;

                // search attributes of
                while (*pCur != '>' && *pCur != ' ' && *pCur != '\n' && *pCur != '\r') {
                    //while (IsCharAlphaNumeric(*pCur) || strchr(":_-.", *pCur) != NULL) {
                    if (insertStringSize == MAX_TAGNAME_LENGTH - 1) return;
                    insertString[insertStringSize++] = *pCur;
                    ++pCur;
                }
            }

            if (insertStringSize == MAX_TAGNAME_LENGTH - 1) return;
            insertString[insertStringSize++] = '>';
            insertString[insertStringSize] = '\0';

            if (insertStringSize > 3) {
                ::SendMessage(hCurrentEditView, SCI_BEGINUNDOACTION, 0, 0);
                ::SendMessage(hCurrentEditView, SCI_REPLACESEL, 0, (LPARAM)insertString);
                ::SendMessage(hCurrentEditView, SCI_SETSEL, currentPos, currentPos);
                ::SendMessage(hCurrentEditView, SCI_ENDUNDOACTION, 0, 0);
            }
        }
    }

#undef MAX_TAGNAME_LENGTH
}

///////////////////////////////////////////////////////////////////////////////

void tagAutoIndent() {
    dbgln("tagAutoIndent()");

    // On n'indente que si l'on est dans un noeud (au niveau de l'attribut ou
    // au niveau du contenu. Donc on recherche le dernier < ou >. S'il s'agit
    // d'un >, on regarde qu'il n'y ait pas de / avant (sinon on se retrouve
    // au m�me niveau et il n'y a pas d'indentation � faire)
    // Si le dernier symbole que l'on trouve est un <, alors on indente.

    char buf[512];
    int currentEdit;
    ::SendMessage(nppData._nppHandle, NPPM_GETCURRENTSCINTILLA, 0, (LPARAM)&currentEdit);
    HWND hCurrentEditView = getCurrentHScintilla(currentEdit);
    Sci_PositionCR currentPos = Sci_PositionCR(::SendMessage(hCurrentEditView, SCI_GETCURRENTPOS, 0, 0));
    Sci_PositionCR beginPos = currentPos - (sizeof(buf) - 1);
    Sci_PositionCR startPos = (beginPos > 0) ? beginPos : 0;
    Sci_PositionCR size = currentPos - startPos;

    struct TextRange tr = { {startPos, currentPos}, buf };
    ::SendMessage(hCurrentEditView, SCI_GETTEXTRANGE, 0, (LPARAM)&tr);

    int tabwidth = (int) ::SendMessage(hCurrentEditView, SCI_GETTABWIDTH, 0, 0);
    bool usetabs = (bool) ::SendMessage(hCurrentEditView, SCI_GETUSETABS, 0, 0);
    if (tabwidth <= 0) tabwidth = 4;

    bool ignoreIndentation = false;
    if (size >= 1) {
        const char* pBegin = &buf[0];
        const char* pCur = &buf[size - 1];

        for (; pCur > pBegin && *pCur != '>';) --pCur;
        if (pCur > pBegin) {
            if (*(pCur - 1) == '/') ignoreIndentation = true;  // si on a "/>", on abandonne l'indentation
            // maintenant, on recherche le <
            while (pCur > pBegin && *pCur != '<') --pCur;
            if (*pCur == '<' && *(pCur + 1) == '/') ignoreIndentation = true; // si on a "</", on abandonne aussi

            int insertStringSize = 0;
            char insertString[516] = { '\0' };

            --pCur;
            // on r�cup�re l'indentation actuelle
            while (pCur > pBegin && *pCur != '\n' && *pCur != '\r') {
                if (*pCur == '\t') insertString[insertStringSize++] = '\t';
                else insertString[insertStringSize++] = ' ';

                --pCur;
            }

            // et on ajoute une indentation
            if (!ignoreIndentation) {
                if (usetabs) insertString[insertStringSize++] = '\t';
                else {
                    for (int i = 0; i < tabwidth; ++i) insertString[insertStringSize++] = ' ';
                }
            }

            currentPos += insertStringSize;

            // on a trouv� le <, il reste � ins�rer une indentation apr�s le curseur
            ::SendMessage(hCurrentEditView, SCI_REPLACESEL, 0, (LPARAM)insertString);
            ::SendMessage(hCurrentEditView, SCI_SETSEL, currentPos, currentPos);
        }
    }
}

LangType setAutoXMLType(bool force = FALSE) {
    dbgln("setAutoXMLType()");

    LangType docType;
    ::SendMessage(nppData._nppHandle, NPPM_GETCURRENTLANGTYPE, 0, (LPARAM)&docType);
    if (force || (config.doAutoXMLType && docType != LangType::L_XML)) {

        int currentEdit;
        ::SendMessage(nppData._nppHandle, NPPM_GETCURRENTSCINTILLA, 0, (LPARAM)&currentEdit);
        HWND hCurrentEditView = getCurrentHScintilla(currentEdit);

        // on r�cup�re les 6 premiers caract�res du fichier
        char head[8] = { '\0' };
        ::SendMessage(hCurrentEditView, SCI_GETTEXT, 7, reinterpret_cast<LPARAM>(&head));

        if (strlen(head) >= 6 && !strcmp(head, "<?xml ")) {
            ::SendMessage(nppData._nppHandle, NPPM_SETCURRENTLANGTYPE, 0, (LPARAM)LangType::L_XML);
            docType = LangType::L_XML;
        }
    }

    return docType;
}