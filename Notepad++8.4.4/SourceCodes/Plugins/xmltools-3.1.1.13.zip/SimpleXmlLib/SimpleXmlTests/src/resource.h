
#define RC_test_pp_indent_input_1		10000
#define RC_test_pp_indent_output_1		10001

#define RC_test_pp_AutoCloseEmptyElement_in		10002
#define RC_test_pp_AutoCloseEmptyElement_out	10003

#define RC_test_pp_AutoCloseEmptyElement_child_in		10004
#define RC_test_pp_AutoCloseEmptyElement_child_out		10005

#define RC_test_pp_Comment_After_PI_in		10006
#define RC_test_pp_Comment_After_PI_out		10007
#define RC_test_pp_FullTest_in				10008
#define RC_test_pp_FullTest_out				10009
#define RC_test_pp_markupdecl_in			10010
#define RC_test_pp_markupdecl_out			10011
#define RC_test_pp_Test1_in					10012
#define RC_test_pp_Test1_out				10013
#define RC_test_pp_xmltag_not_closed_in		10014
#define RC_test_pp_xmltag_not_closed_out	10015

#define RC_test_pp_attributes_space_indented_in		10016
#define RC_test_pp_attributes_space_indented_out	10017
#define RC_test_pp_attributes_tab_indented_in		10018
#define RC_test_pp_attributes_tab_indented_out		10019
