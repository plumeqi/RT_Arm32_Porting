#include <string>
#include "resource.h"

std::string LoadEmbeddedResourceText(int assetId);