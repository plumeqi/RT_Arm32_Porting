#ifndef SIMPLEXML_HEADER_FILE_H
#define SIMPLEXML_HEADER_FILE_H


#include "PrettyPrinter.h"

namespace SimpleXml {

}

#endif