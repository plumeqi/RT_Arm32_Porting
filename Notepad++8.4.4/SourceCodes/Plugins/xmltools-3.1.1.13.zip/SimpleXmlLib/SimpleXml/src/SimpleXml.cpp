#include "SimpleXml.h"
#include "TextEncoding.h"

namespace SimpleXml {

}