#ifndef RESOURCE_H
#define RESOURCE_H

#ifndef IDC_STATIC 
#define IDC_STATIC -1
#endif

// About dialog
#define IDD_ABOUTBOX                250
#define IDC_CORE_VERSION            251
#define IDC_SYSLINK                 252

#endif // RESOURCE_H
