//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FileSwitcherDialogs.rc
//
#define IDD_SWITCHDIALOG                101
#define IDD_ABOUTDIALOG                 102
#define IDD_DIALOG1                     103
#define IDD_CONFIGDIALOG                103
#define IDB_SORTUP                      107
#define IDB_SORTDOWN                    108
#define IDI_UNSAVED                     109
#define IDI_READONLY                    110
#define IDI_SAVED                       111
#define IDC_EDIT1                       1001
#define IDC_FILEEDIT                    1001
#define IDC_FILELIST                    1002
#define IDC_CHECKCASE                   1003
#define IDC_CHECKANYPART                1004
#define IDC_CHECKSTARTONLY              1004
#define IDC_CHECKINCLUDEPATH            1005
#define IDC_CTRLTAB                     1006
#define IDC_CHECKCTRLTAB                1006
#define IDC_CHECKONLYCURRENTVIEW        1006
#define IDC_CHECKINCLUDEFILENAME        1007
#define IDC_LIST1                       1008
#define IDC_LISTVIEW                    1008
#define IDC_CHECKINCLUDEINDEX           1008
#define IDC_CHECKAUTOSIZECOLUMNS        1009
#define IDC_CHECKAUTOSIZEWINDOW         1010
#define IDC_RADIOSORTREMEMBER           1011
#define IDC_RADIOSORTFILENAME           1012
#define IDC_RADIOSORTPATH               1013
#define IDC_RADIOSORTINDEX              1014
#define IDC_CHECKRESETSORTORDER         1015
#define IDC_CHECKSORTDESCENDING         1016
#define IDC_CHECKOVERRIDESORTWHENTABBING 1017
#define IDC_OPTIONS                     1017
#define IDC_CHECKREVERTSORTORDERDURINGTABBING 1018
#define IDC_CHECKINCLUDEVIEW            1019
#define IDC_CHECKSEPARATECOLUMNFORVIEW  1020
#define IDC_CHECKNODIALOGFORCTRLTAB     1021
#define IDC_CHECKDIALOGFORCTRLTAB       1021
#define IDC_LABELCTRLTAB                1022
#define IDC_CHECK1                      1023
#define IDC_CHECKUSEHOMEFOREDIT         1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
