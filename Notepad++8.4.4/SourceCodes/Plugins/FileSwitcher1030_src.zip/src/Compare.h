#ifndef _COMPARE_H
#define _COMPARE_H

#include <tchar.h>

LPTSTR _tcsistr(LPCTSTR string, LPCTSTR strCharSet);

#endif /* _COMPARE_H*/