This is the Fileswitcher plugin, allowing you to quickly switch files in Notepad++

Type any part of the filename, and the list of options shows filenames containing that text.  
Options to only use the start of the filename, case sensitivity and to include the path of the 
file rather than just the filename are available in the options` dialog.



Source available from http://www.brotherstone.co.uk/npp/Fileswitcher_src.zip

  