# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.2.x | :white_check_mark: |
| 0.1.1.x | :white_check_mark: |
| 0.1.0.x | :x:                |

## Reporting a Vulnerability

Please send a private message to the administrator of the repository. You should get a message back within a week.
If you don't get a message within a week, please post a new issue for everyone to see. 
