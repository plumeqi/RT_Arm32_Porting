#ifndef _settings_dlg_h_
#define _settings_dlg_h_
//---------------------------------------------------------------------------
#include "core/base.h"


INT_PTR CALLBACK SettingsDlgProc(HWND, UINT, WPARAM, LPARAM);

//---------------------------------------------------------------------------
#endif
