
// Used by XBrackets.rc
//

#ifndef IDC_STATIC
  #define IDC_STATIC (-1)
#endif

#define IDD_SETTINGS                          101
#define IDC_CH_BRACKETS_AUTOCOMPLETE          1001
#define IDC_BT_OK                             1004
#define IDC_BT_CANCEL                         1005
#define IDC_CH_BRACKETS_RIGHTEXISTS_OK        1008
#define IDC_ST_PLUGINSTATE                    1009
#define IDC_CH_BRACKETS_DOSINGLEQUOTE         1010
#define IDC_CH_BRACKETS_DOTAG                 1011
#define IDC_CH_BRACKETS_DOTAGIF               1012
#define IDC_ED_BRACKETS_DOTAGIF               1013
#define IDC_CH_BRACKETS_DOTAG2                1014
#define IDC_CH_BRACKETS_SKIPESCAPED           1015

