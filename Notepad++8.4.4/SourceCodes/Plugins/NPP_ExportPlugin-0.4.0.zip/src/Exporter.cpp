#include "stdafx.h"
#include "Exporter.h"

Exporter::~Exporter(void) {
}
