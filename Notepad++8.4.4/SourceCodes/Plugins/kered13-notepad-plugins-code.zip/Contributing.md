# TODO

* Add support for remaining LSP methods.
* Add options to enable or disable methods.
* Add options for PublishDiagnostics appearance.
* Add an options UI.

# Formatting Style:

* Naming:
  * UpperCamelCase for file names.
  * UpperCamelCase for types.
  * lowerCamelCase for functions, methods, and variables.
  * Object fields have a trailing underscore, example_, unless the struct is a dumb POD.
* Indent with tabs, align with spaces. Visual Studio doesn't play nicely with this style, alignment spaces will be replaced with tabs whenever automatic formatting runs. Be sure to restore the alignment spaces if this happens. As a consequence of this rule, tab size does not matter.
  * Multi-line macro definitions are indented with spaces. Trailing \ should be aligned for the entire macro definition.
* There is no strict line limit, try to wrap where it is natural and improves readability.
  * Consider 120 columns a "soft" limit, lines should rarely exceed this.
  * Wrap comments at 80 columns, this is a hard limit except where impossible (ex, a diagram in the comment or a link).
* Opening braces go on the same line, except in projects where the style of putting braces on a new line is already established.
* Braces are always mandatory, even for single line control structures.
* Include statements are grouped and separated by an empty line:
  1. (For a .cpp file) The associated header file.
  2. Standard and Windows headers.
  3. Third party headers (vcpkg).
  4. Local headers.
  * Each include group is sorted alphabetically, ignoring case.
* Use header guards, not #pragma once. Header guard name should be the header file name in SCREAMING_SNAKE_CASE_H_.
* Close namespaces and header guards with a comment repeating the name.
* Case statements are always indented.
* For any other style questions, try to match existing code.
