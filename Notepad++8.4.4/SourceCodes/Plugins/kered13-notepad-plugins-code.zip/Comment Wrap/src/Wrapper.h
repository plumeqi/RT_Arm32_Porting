#ifndef WRAPPER_H
#define WRAPPER_H

#include <optional>
#include <string_view>
#include <string>
#include <vector>

#include "LanguageCommentStyle.h"
#include "NppUtils/ScintillaUtils.h"
#include "NppUtils/ScintillaTypes.h"


struct PreWrapPositions {
	// First position where edits are made.
	Position wrapStart;
	// First non-whitespace position in wrapped text.
	Position trimmedStart;
	// Final non-whitespace position in wrapped text.
	Position trimmedEnd;
	// End of the wrapped line.
	Position lineEnd;
};

struct PostWrapPositions {
	// Position where text insertion began. This is the start of the line if a
	// new line was inserted, or the insertTextStart otherwise.
	Position insertStart;
	// Position where text that was wrapped from the previous line was inserted.
	Position textStart;
	// Position at the end of text that was wrapped from the previous line.
	Position insertEnd;
};

// An object that performs text wrapping on the given document and using the
// given comment style.
class Wrapper {
public:
	Wrapper(Scintilla& scintilla, const LanguageCommentStyle* const commentStyle, const Column wrapColumn)
		: scintilla_(scintilla), commentStyle_(commentStyle), wrapColumn_(wrapColumn) {}
	virtual ~Wrapper() = default;

	// Wrap the text at the current selection.
	void wrapSelection() const;

	// Insert a new comment line before the given line using the indentation of
	// the previous line. Returns the position after indentation and comment
	// prefix on the new line.
	Position insertNewlineAfter(const LineNumber lineNumber) const;

private:
	// Wrap text at the given line. If the next line is a non-empty comment then
	// wrapped text will be inserted at the beginning of that line, otherwise
	// wrapped text will be inserted on a new line. Either way the next line
	// will also be wrapped. Returns the linenumber of the first line AFTER the
	// end of wrapping.
	LineNumber wrapLine(const LineNumber lineNumber) const;

	PostWrapPositions wrapIntoNextLine(LineNumber lineNumber, std::string_view prefix, std::string_view wrappedText) const;
	PostWrapPositions wrapIntoNewLine(LineNumber lineNumber, std::string_view wrappedText) const;

	// Returns an iterator to the first character that should be wrapped.
	// Includes any white space that should be trimmed before wrapping.
	std::string::const_iterator getWrapStart(const LineNumber lineNumber, const std::string& line) const;

	// Returns true if the end of the given line is greater than the wrapColumn_.
	bool isLineLong(const LineNumber lineNumber) const;

	// Check if the given line is a comment that contains text other than
	// comment marks and whitespace.
	bool isNonEmptyComment(const std::string_view line, const LineNumber lineNumber, const std::string_view prefix) const;

	Scintilla& scintilla_;
	const LanguageCommentStyle* const commentStyle_;
	const Column wrapColumn_;
};

#endif WRAPPER_H
