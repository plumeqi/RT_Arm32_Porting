#include "CommentWrap.h"

#include <functional>
#include <optional>
#include <stdio.h>
#include <string>

#include <absl/strings/str_cat.h>

#include "LanguageCommentStyle.h"
#include "NppUtils/NppUtilsImpl.h"
#include "NppUtils/ScintillaUtils.h"
#include "NppUtils/ScintillaTypes.h"
#include "NppUtils/StringUtils.h"
#include "Wrapper.h"


std::unique_ptr<NppUtils> gNppUtils;
std::unique_ptr<CommentWrap> gPlugin;

BOOL APIENTRY DllMain(HANDLE hModule, DWORD  reasonForCall, LPVOID /*lpReserved*/) {
	switch(reasonForCall) {
		case DLL_PROCESS_ATTACH:
			break;

		case DLL_PROCESS_DETACH:
			// Delete plugin and trigger cleanup.
			gPlugin = nullptr;
			gNppUtils = nullptr;
			break;

		case DLL_THREAD_ATTACH:
			break;

		case DLL_THREAD_DETACH:
			break;
	}

	return true;
}

extern "C" __declspec(dllexport) void setInfo(NppData nppData) {
	gNppUtils = std::make_unique<NppUtilsImpl>(nppData);
	gPlugin = std::make_unique<CommentWrap>(nppData, *gNppUtils);
}

extern "C" __declspec(dllexport) const wchar_t* getName() {
	return CommentWrap::kPluginName_;
}

extern "C" __declspec(dllexport) FuncItem* getFuncsArray(int* nbF) {
	std::vector<FuncItem>& funcItems = gPlugin->getFuncItems();
	*nbF = (int)funcItems.size();
	return funcItems.data();
}

bool newlineAdded = false;

enum class CharAddedState {
	kIdle, kArmed, kAdded
};
CharAddedState charAdded = CharAddedState::kIdle;

extern "C" __declspec(dllexport) void beNotified(SCNotification* notifyCode) {
	switch(notifyCode->nmhdr.code) {
		case SCN_CHARADDED:
		{
			if(notifyCode->ch == '\n') {
				newlineAdded = true;
			}
			break;
		}
		case SCN_MODIFIED:
		{
			if((notifyCode->modificationType & (SC_MOD_INSERTTEXT | SC_PERFORMED_USER)) == (SC_MOD_INSERTTEXT | SC_PERFORMED_USER)) {
				std::string insertText(notifyCode->text, notifyCode->length);
				// Don't wrap on whitespace.
				if(insertText != " " && insertText != "\t") {
					charAdded = CharAddedState::kArmed;
				}
			}
			if(notifyCode->modificationType & SC_PERFORMED_UNDO) {
				charAdded = CharAddedState::kIdle;
			}
			if(charAdded == CharAddedState::kArmed && (notifyCode->modificationType & (SC_MOD_CHANGESTYLE | SC_PERFORMED_USER)) == (SC_MOD_CHANGESTYLE | SC_PERFORMED_USER)) {
				charAdded = CharAddedState::kAdded;
			}
			break;
		}
		case SCN_UPDATEUI:
		{
			if(newlineAdded) {
				gPlugin->autoComment();
				newlineAdded = false;
			}
			if(charAdded == CharAddedState::kAdded) {
				gPlugin->autoWrap();
				charAdded = CharAddedState::kIdle;
			}
			break;
		}
	}
}


// Here you can process the Npp Messages 
// I will make the messages accessible little by little, according to the need of plugin development.
// Please let me know if you need to access to some messages :
// http://sourceforge.net/forum/forum.php?forum_id=482781
//
extern "C" __declspec(dllexport) LRESULT messageProc(UINT /*Message*/, WPARAM /*wParam*/, LPARAM /*lParam*/) {/*
	if (Message == WM_MOVE)
	{
		::MessageBox(nullptr, "move", "", MB_OK);
	}
*/
	return true;
}

extern "C" __declspec(dllexport) BOOL isUnicode() {
	return true;
}


//
// Helper functions.
//
void commentLine(Scintilla& scintilla, const LanguageCommentStyle& commentStyle, const LineNumber lineNumber) {
	const auto undo = scintilla.getUndoAction();

	const std::string indent = scintilla.getLineIndent(lineNumber - 1_dln);
	const Position insertPosition = scintilla.setLineIndent(lineNumber, indent);
	const Position newPosition = scintilla.insertText(insertPosition, commentStyle.getNewlinePrefix(scintilla, lineNumber - 1_dln));
	scintilla.gotoPos(newPosition);
}


CommentWrap::CommentWrap(const NppData& nppData, NppUtils& nppUtils) :
	NppPlugin(wstringToString(kPluginName_), nppData, nppUtils),
	continueComments_(readSetting<bool>("ContinueComments")),
	autoWrap_(readSetting<bool>("EnableAutoWrap")),
	wrapAtColumn_(Column(readSetting<int>("WrapAtColumn", 0))) {
	const std::string wrapAtColumnButton = wrapAtColumn_ == 0_col ?
		"Wrap at Column: 0 (Vertical Edge)" :
		absl::StrCat("Wrap at Column: ", *wrapAtColumn_);

	// Setup the menu.
	nppMenu_.addItem("Wrap Current or Selected Lines", std::bind(&CommentWrap::wrapSelection, this));
	nppMenu_.addToggleItem("Automatically Wrap Comments", autoWrap_, nppData_);
	nppMenu_.addItem("Insert New Comment Line", std::bind(&CommentWrap::insertCommentLine, this));
	nppMenu_.addToggleItem("Automatically Insert New Comment Lines", continueComments_, nppData_);
	nppMenu_.addItem(wrapAtColumnButton, std::bind(&CommentWrap::showWrapColumnMessage, this));
}

CommentWrap::~CommentWrap() {
	writeSetting<bool>("ContinueComments", continueComments_);
	writeSetting<bool>("EnableAutoWrap", autoWrap_);
	// WrapAtColumn is not written. This needs to be manually edited. The user
	// may have editted this using Notepad++, so we don't want to override that
	// here.
}

void CommentWrap::autoWrap() {
	if(autoWrap_) {
		wrapSelection();
	}
}

void CommentWrap::wrapSelection() {
	const std::shared_ptr<Scintilla> scintilla = nppUtils_.getCurrentScintilla();
	if(!scintilla) {
		return;
	}

	const LanguageCommentStyle* const commentStyle = LanguageCommentStyle::getLanguageCommentStyle(scintilla->getLexer());
	if(!commentStyle) {
		return;
	}
	const auto undo = scintilla->getUndoAction();
	Wrapper wrapper(*scintilla, commentStyle, getWrapColumn());
	wrapper.wrapSelection();
}

Column CommentWrap::getWrapColumn() {
	if(wrapAtColumn_ == 0_col) {
		// Use the vertical edge for wrapping.
		const std::shared_ptr<Scintilla> scintilla = nppUtils_.getCurrentScintilla();
		if(!scintilla) {
			return 0_col;
		}
		return Column(scintilla->sendMessage(SCI_GETEDGECOLUMN));
	} else {
		return wrapAtColumn_;
	}
}

void CommentWrap::showWrapColumnMessage() {
	const std::wstring aboutMessage =
		L"To set the wrap column edit the WrapAtColumn field in \"Comment Wrap.ini\" in your plugins config folder and restart Notepad++.\n\n"
		L"Set WrapAtColumn=0 to wrap at the vertical edge.\n\n"
		L"\"Comment Wrap.ini\" will now open.";
	MessageBox(nppData_._nppHandle, aboutMessage.c_str(), L"Comment Wrap", MB_OK);
	SendMessage(nppData_._nppHandle, NPPM_DOOPEN, 0, reinterpret_cast<LPARAM>(getIniFilePath().c_str()));
}

void CommentWrap::autoComment() {
	if(!continueComments_) {
		return;
	}
	const std::shared_ptr<Scintilla> scintilla = nppUtils_.getCurrentScintilla();
	if(!scintilla) {
		return;
	}

	const LanguageCommentStyle* const commentStyle = LanguageCommentStyle::getLanguageCommentStyle(scintilla->getLexer());
	const LineNumber lineNumber = scintilla->lineFromPosition(scintilla->getCurrentPos());
	if(commentStyle && commentStyle->shouldAutoComment(*scintilla, lineNumber - 1_dln)) {
		commentLine(*scintilla, *commentStyle, lineNumber);
	}
}

void CommentWrap::insertCommentLine() {
	const std::shared_ptr<Scintilla> scintilla = nppUtils_.getCurrentScintilla();
	if(!scintilla) {
		return;
	}

	const LanguageCommentStyle* const commentStyle = LanguageCommentStyle::getLanguageCommentStyle(scintilla->getLexer());
	const LineNumber lineNumber = scintilla->lineFromPosition(scintilla->getCurrentPos());
	if(commentStyle && commentStyle->isComment(*scintilla, lineNumber)) {
		const Position newPosition = scintilla->insertText(scintilla->getCurrentPos(), scintilla->getEol());
		scintilla->gotoPos(newPosition);
		commentLine(*scintilla, *commentStyle, lineNumber + 1_dln);
	} else {
		// Insert a new line normally. This ensures all the normal new line behavior
		// applies.
		scintilla->sendMessage(SCI_NEWLINE);
	}
}