#ifndef COMMENTWRAP_H
#define COMMENTWRAP_H

#include "NppUtils/NppPlugin.h"
#include "NppUtils/NppUtils.h"


class CommentWrap : public NppPlugin {
public:
	//-------------------------------------//
	//-- STEP 1. DEFINE YOUR PLUGIN NAME --//
	//-------------------------------------//
	static constexpr wchar_t kPluginName_[] = L"Comment Wrap";

	// Initialize your plugin data and commands here.
	CommentWrap(const NppData& nppData, NppUtils& nppUtils);

	// Here you can do the clean up, save the parameters (if any) for the next session
	~CommentWrap();

	//------------------------------------------//
	//-- STEP 2. DEFINE YOUR PLUGIN FUNCTIONS --//
	//------------------------------------------//
	void autoComment();
	void autoWrap();

private:
	void wrapSelection();
	void showWrapColumnMessage();
	void insertCommentLine();
	Column getWrapColumn();

	bool continueComments_;
	bool autoWrap_;
	Column wrapAtColumn_;
};

#endif //COMMENTWRAP_H