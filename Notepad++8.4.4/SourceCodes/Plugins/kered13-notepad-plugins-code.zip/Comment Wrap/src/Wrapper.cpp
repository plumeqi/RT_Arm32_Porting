#include "Wrapper.h"

#include <assert.h>
#include <iterator>
#include <windows.h>

#include "NppUtils/StringUtils.h"


// Returns a new vector containing a copy of the trimmed text to wrap. If there
// is nothing to wrap then an empty vector is returned.
std::string_view getTrimmedWrap(const std::string_view text) {
	return stripLeadingWhitespace(stripTrailingWhitespace(text));
}

void Wrapper::wrapSelection() const {
	const Position selectionStart = scintilla_.getSelectionStart();
	LineNumber lineNumber = scintilla_.lineFromPosition(selectionStart);

	// Check if the selection ends at the start of the last line. If not, or if the
	// start and end are the same, we wrap the last line as well.
	const Position selectionEnd = scintilla_.getSelectionEnd();
	const DLineNumber fudge =
		selectionStart != selectionEnd && selectionEnd == scintilla_.positionFromLine(scintilla_.lineFromPosition(selectionEnd)) ?
		0_dln : 1_dln;
	// Get the selection end again on each loop because wrapping may make it
	// move.
	while(lineNumber < scintilla_.lineFromPosition(scintilla_.getSelectionEnd()) + fudge) {
		if(isLineLong(lineNumber) && commentStyle_->isComment(scintilla_, lineNumber)) {
			lineNumber = wrapLine(lineNumber);
		} else {
			lineNumber++;
		}
	}
}

// Calculate a new position from the given position accounting for the deleted
// and inserted text. There are several cases.
//
// This is extremely complicated because I'm a fucking retard who can't figure
// it out.
Position calculateNewPosition(
	// Input position before deletion and insertion.
	const Position oldPosition,
	const PreWrapPositions preWrap,
	const PostWrapPositions postWrap) {
	const DPosition deletedPositions = preWrap.lineEnd - preWrap.wrapStart;
	// The characters that were moved to the next line.
	const DPosition insertedTextPositions = preWrap.trimmedEnd - preWrap.trimmedStart;
	// Includes inserted newline, whitespace, and in prefix characters.
	const DPosition totalInsertedPositions = postWrap.insertEnd - postWrap.insertStart;

	// There are two cases:
	// 1. The lined wrapped into a new line. Then lineEnd == insertStart + deletedPositions.
	// 2. The line wrapped into an existing line. Then insertStart == textStart.
	assert(preWrap.lineEnd == postWrap.insertStart + deletedPositions ||
	       postWrap.insertStart == postWrap.textStart);

	// We could let Scintilla handle the first and last case automatically, but
	// it simplifies the other logic to just do them here.

	// Position before wrap: Do nothing.
	if(oldPosition <= preWrap.wrapStart) {
		return oldPosition;
	}
	// Position in deleted whitespace before wrap: Beginning of new line.
	else if(oldPosition < preWrap.trimmedStart) {
		return postWrap.textStart;
	}
	// Position in wrapped text: Same position relative to wrapped text on new line.
	else if(oldPosition < preWrap.trimmedEnd) {
		return postWrap.textStart + (oldPosition - preWrap.trimmedStart);
	}
	// Position in deleted whitespace after wrap: End of wrapped text on new line.
	else if(oldPosition <= preWrap.lineEnd) {
		return postWrap.textStart + insertedTextPositions;
	}
	// Position is after old text position but before new text position.
	// This can only happen when wrapping into an existing line.
	else if(oldPosition < postWrap.insertStart + deletedPositions) {
		return postWrap.insertEnd;
	}
	// Position after wrapped text:
	else {
		return oldPosition - deletedPositions + totalInsertedPositions;
	}
}

LineNumber Wrapper::wrapLine(const LineNumber lineNumber) const {
	const Position position = scintilla_.getCurrentPos();
	const Position anchor = scintilla_.getAnchor();

	const Position lineStart = scintilla_.positionFromLine(lineNumber);
	const std::string line = scintilla_.getLine(lineNumber);
	const std::string nextLine = scintilla_.getLine(lineNumber + 1_dln);

	auto wrapStart = getWrapStart(lineNumber, line);
	std::string_view wrappedText = getTrimmedWrap(subStr(wrapStart, line.end()));

	const Position wrapStartPosition = lineStart + DPosition(wrapStart - line.begin());
	// We can't compare or subtract iterators from different objects, but
	// strings and views are guaranteed to be contiguous, so this
	// subtraction is valid.
	const Position trimmedStartPosition = lineStart + DPosition(wrappedText.data() - line.data());
	const Position trimmedEndPosition = trimmedStartPosition + DPosition(wrappedText.size());
	const Position lineEndPosition = lineStart + DPosition(line.size());

	// Delete the wrapping text.
	scintilla_.deleteRange(wrapStartPosition, lineEndPosition - wrapStartPosition);

	if(wrappedText.empty()) {
		return lineNumber + 1_dln;
	}

	const std::string prefix = commentStyle_->getNewlinePrefix(line);
	const PostWrapPositions postWrap = isNonEmptyComment(nextLine, lineNumber + 1_dln, prefix) ?
		wrapIntoNextLine(lineNumber, prefix, wrappedText) :
		wrapIntoNewLine(lineNumber, wrappedText);

	// Update anchor and position.
	const Position newPosition = calculateNewPosition(position,
		{wrapStartPosition, trimmedStartPosition, trimmedEndPosition, lineEndPosition}, postWrap);
	const Position newAnchor = calculateNewPosition(anchor,
		{wrapStartPosition, trimmedStartPosition, trimmedEndPosition, lineEndPosition}, postWrap);
	scintilla_.setCurrentPos(newPosition);
	scintilla_.setAnchor(newAnchor);

	// Either way, next line may need to be wrapped now.
	const LineNumber nextLineNumber = lineNumber + 1_dln;
	return isLineLong(nextLineNumber) ?
		wrapLine(nextLineNumber) :
		nextLineNumber;
}

PostWrapPositions Wrapper::wrapIntoNextLine(LineNumber lineNumber, std::string_view prefix, std::string_view wrappedText) const {
	const Position insertStartPosition = scintilla_.getLineIndentPosition(lineNumber + 1_dln) + DPosition(prefix.size());
	const Position insertTextStartPosition = insertStartPosition;
	const Position insertEndPosition = scintilla_.insertText(insertStartPosition, wrappedText, " ");
	return {insertStartPosition, insertTextStartPosition, insertEndPosition};
}

PostWrapPositions Wrapper::wrapIntoNewLine(LineNumber lineNumber, std::string_view wrappedText) const {
	const Position insertStartPosition = scintilla_.getLineEndPosition(lineNumber);
	const Position insertTextStartPosition = insertNewlineAfter(lineNumber);
	const Position insertEndPosition = scintilla_.insertText(insertTextStartPosition, wrappedText);
	return {insertStartPosition, insertTextStartPosition, insertEndPosition};
}

Position Wrapper::insertNewlineAfter(const LineNumber lineNumber) const {
	const std::string indent = scintilla_.getLineIndent(lineNumber);
	const Position insertPosition = scintilla_.getLineEndPosition(lineNumber);
	return scintilla_.insertText(insertPosition, scintilla_.getEol(), indent, commentStyle_->getNewlinePrefix(scintilla_, lineNumber));
}

std::string::const_iterator Wrapper::getWrapStart(const LineNumber lineNumber, const std::string& line) const {
	// First, find the first position that can be wrapped. We don't want to wrap
	// words that consume the entire line, as this would lead to an infinite
	// loop.
	auto iter = line.begin();
	iter = skipWhitespace(iter, line.end());
	// First "word" is the comment prefix.
	iter = skipWord(iter, line.end());
	iter = skipWhitespace(iter, line.end());
	// Finally the first real word. We don't want to wrap this.
	iter = skipWord(iter, line.end());

	auto wrapStart = iter;

	// Start iter at the wrap column.
	const Position lineStart = scintilla_.positionFromLine(lineNumber);
	const Position lineWrap = scintilla_.findColumn(lineNumber, wrapColumn_);
	iter = line.begin() + (*lineWrap - *lineStart);

	// wrapStart may be past the wrap column, in that case just return wrapStart.
	// If this is the end of the line then nothing will be wrapped.
	if(iter <= wrapStart) {
		return wrapStart;
	}

	// Find the end of the current word.
	while(iter > wrapStart && !isWhitespace(*iter)) {
		--iter;
	}
	// Find the beginning of the next word.
	while(iter > wrapStart && isWhitespace(*(iter-1))) {
		--iter;
	}
	return iter;
}

bool Wrapper::isLineLong(const LineNumber lineNumber) const {
	const Position lineEnd = scintilla_.getLineEndPosition(lineNumber);
	const Position lineWrap = scintilla_.findColumn(lineNumber, wrapColumn_);
	return lineWrap < lineEnd;
}

bool Wrapper::isNonEmptyComment(const std::string_view line, const LineNumber lineNumber, const std::string_view prefix) const {
	if(!commentStyle_->isComment(scintilla_, lineNumber)) {
		return false;
	}
	const auto strippedPrefix = stripTrailingWhitespace(prefix);
	const std::string_view trimmedLine = stripLeadingWhitespace(line);
	if(trimmedLine.size() < strippedPrefix.size()) {
		return false;
	}
	for(auto iter = trimmedLine.begin() + strippedPrefix.size();
		iter != trimmedLine.end(); ++iter) {
		if(!isWhitespace(*iter) && !isNullChar(*iter)) {
			return true;
		}
	}
	return false;
}
