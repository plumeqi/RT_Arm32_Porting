#include "LanguageCommentStyle.h"

#include <algorithm>
#include <memory>
#include <sstream>
#include <vector>
#include <Windows.h>

#include "NppUtils/NPP/SciLexer.h"
#include "NppUtils/ScintillaUtils.h"
#include "NppUtils/StringUtils.h"


// If you would like support for additional langauges please create a pull
// request.

SingleLine doubleSlash("//");
SingleLine tripleSlash("///");
SingleLine singleHash("#");
SingleLine doubleHash("##");
SingleLine luaSingleLine("--");
MultiLine cMultiLine("/*", " *", "*/");
MultiLine dNestedMultiLine("/+", " +", "+/");

// Some common recurring patterns.
#define C_STYLE &tripleSlash, &doubleSlash, &cMultiLine
#define HASH_STYLE &doubleHash, &singleHash

// C, C++, C#, Objective-C, Java, Javascript, Swift, JSON, etc.
LanguageCommentStyle cStyleComment(
	{SCE_C_COMMENT, SCE_C_COMMENTLINE, SCE_C_COMMENTDOC, SCE_C_COMMENTLINEDOC, SCE_C_COMMENTDOCKEYWORD, SCE_C_COMMENTDOCKEYWORDERROR},
	{C_STYLE});

LanguageCommentStyle rustComment(
	{SCE_RUST_COMMENTBLOCK, SCE_RUST_COMMENTBLOCKDOC, SCE_RUST_COMMENTLINE, SCE_RUST_COMMENTLINEDOC},
	{C_STYLE});

LanguageCommentStyle dComment(
	{SCE_D_COMMENT, SCE_D_COMMENTLINE, SCE_D_COMMENTDOC, SCE_D_COMMENTNESTED, SCE_D_COMMENTLINEDOC, SCE_D_COMMENTDOCKEYWORD,
	 SCE_D_COMMENTDOCKEYWORDERROR},
	{C_STYLE, &dNestedMultiLine});

LanguageCommentStyle pythonComment(
	{SCE_P_COMMENTLINE, SCE_P_COMMENTBLOCK, SCE_P_TRIPLEDOUBLE},
	{HASH_STYLE});

LanguageCommentStyle rubyComment(
	{SCE_RB_COMMENTLINE, SCE_RB_POD},
	{HASH_STYLE});

LanguageCommentStyle luaComment(
	{SCE_LUA_COMMENT, SCE_LUA_COMMENTLINE, SCE_LUA_COMMENTDOC},
	{&luaSingleLine});

LanguageCommentStyle perlComment(
	{SCE_PL_COMMENTLINE, SCE_PL_POD, SCE_PL_POD_VERB},
	{HASH_STYLE});

// HTML and XML.
LanguageCommentStyle htmlComment(
	{SCE_H_COMMENT, SCE_H_SGML_COMMENT, SCE_H_SGML_1ST_PARAM_COMMENT, SCE_HJ_COMMENT, SCE_HJ_COMMENTLINE, SCE_HJ_COMMENTDOC,
	 SCE_HB_COMMENTLINE, SCE_HBA_COMMENTLINE, SCE_HP_COMMENTLINE, SCE_HPA_COMMENTLINE, SCE_HPHP_COMMENT, SCE_HPHP_COMMENTLINE},
	{});

LanguageCommentStyle cssComment(
	{SCE_CSS_COMMENT},
	{C_STYLE});


std::string CommentStyle::getNewlinePrefixWithPadding(const std::string_view line) const {
	const std::string_view lineWithoutIndent = stripLeadingWhitespace(line);
	const std::string_view prefix = getNewlinePrefix(lineWithoutIndent);
	const auto prefixBegin = lineWithoutIndent.begin();
	const auto prefixEnd = skipWhitespace(prefixBegin + prefix.size(), lineWithoutIndent.end());
	const size_t padding = std::max<size_t>(std::distance(prefixBegin, prefixEnd) - prefix.size(), 0);

	std::ostringstream os;
	os << prefix << std::string(padding, ' ');
	return os.str();
}

bool SingleLine::matchLine(const std::string_view line) const {
	return startsWith(stripLeadingWhitespace(line), prefix_);
}

const std::string_view SingleLine::getNewlinePrefix(const std::string_view lineWithoutIndent) const {
	return prefix_;
}

bool SingleLine::shouldAutoComment(const LanguageCommentStyle& languageStyle, const Scintilla& scintilla, const LineNumber lineNumber) const {
	// The next line is the newline, so it will never be a comment (yet). We
	// check the line after that. Implicitely, if this is the end of the
	// document we do not continue the comment block.
	return languageStyle.isComment(scintilla, lineNumber + 2_dln);
}


bool MultiLine::matchLine(const std::string_view line) const {
	const std::string_view lineWithoutIndent = stripLeadingWhitespace(line);
	return startsWith(lineWithoutIndent, begin_) || startsWith(lineWithoutIndent, stripLeadingWhitespace(continue_));
}

const std::string_view MultiLine::getNewlinePrefix(const std::string_view lineWithoutIndent) const {
	// Leading whitespace is used in continue_ to control alignment with begin_,
	// but if the previous line was a continue_ then autoindent will have
	// already included this whitespace, so we strip it from the prefix.
	if(startsWith(lineWithoutIndent, begin_)) {
		return continue_;
	} else {
		return stripLeadingWhitespace(continue_);
	}
}

bool MultiLine::shouldAutoComment(const LanguageCommentStyle& languageStyle, const Scintilla& scintilla, const LineNumber lineNumber) const {
	// The next line is the newline, so it will never be a comment (yet). We
	// check the line after that. If the document ends then there must be no
	// comment end sequence, so we continue the comment block.
	return lineNumber + 2_dln >= scintilla.getLineCount() || languageStyle.isComment(scintilla, lineNumber + 2_dln);
}


LanguageCommentStyle* LanguageCommentStyle::getLanguageCommentStyle(const Lexer lexer) {
	switch(*lexer) {
		case SCLEX_CPP:
			return &cStyleComment;
		case SCLEX_RUST:
			return &rustComment;
		case SCLEX_D:
			return &dComment;
		case SCLEX_PYTHON:
			return &pythonComment;
		case SCLEX_RUBY:
			return &rubyComment;
		case SCLEX_LUA:
			return &luaComment;
		case SCLEX_PERL:
			return &perlComment;
		case SCLEX_HTML:
		case SCLEX_XML:
			return &htmlComment;
		case SCLEX_CSS:
			return &cssComment;
		default:
			return nullptr;
	}
}

bool LanguageCommentStyle::isComment(const Scintilla& scintilla, const LineNumber lineNumber) const {
	if(lineNumber >= scintilla.getLineCount()) {
		return false;
	}

	// We don't need to be exact here. Trim left and right whitespace, then check
	// that every character in between is some type of comment. The lexer may
	// change styles in the middle of a comment (ex, for javadoc reference), so we
	// don't require that every character is the same style.
	const std::vector<StyledChar> styledLine = scintilla.getStyledLine(lineNumber);
	auto textBegin = skipWhitespace(styledLine.begin(), styledLine.end());
	auto textEnd = skipWhitespace(styledLine.rbegin(), std::reverse_iterator(textBegin)).base();
	if(textBegin == textEnd) {
		return false;
	}
	for(auto iter = textBegin; iter != textEnd; ++iter) {
		if(!commentTextStyles_.count(iter->style)) {
			return false;
		}
	}
	return true;
}

std::string LanguageCommentStyle::getNewlinePrefix(const Scintilla& scintilla, const LineNumber lineNumber) const {
	return getNewlinePrefix(scintilla.getLine(lineNumber));
}

std::string LanguageCommentStyle::getNewlinePrefix(const std::string_view line) const {
	const CommentStyle* commentStyle = getCommentStyle(line);
	return commentStyle ? commentStyle->getNewlinePrefixWithPadding(line) : "";
}

bool LanguageCommentStyle::shouldAutoComment(const Scintilla& scintilla, const LineNumber lineNumber) const {
	if(!isComment(scintilla, lineNumber)) {
		return false;
	}

	const CommentStyle* commentStyle = getCommentStyle(scintilla.getLine(lineNumber));
	return commentStyle ? commentStyle->shouldAutoComment(*this, scintilla, lineNumber) : false;
}

const CommentStyle* LanguageCommentStyle::getCommentStyle(const std::string_view line) const {
	for(const auto commentStyle : commentStyles_) {
		if(commentStyle->matchLine(line)) {
			return commentStyle;
		}
	}
	return nullptr;
}
