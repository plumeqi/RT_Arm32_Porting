#ifndef COMMENT_H
#define COMMENT_H

#include <windows.h>

#include <absl/container/flat_hash_set.h>

#include "NppUtils/ScintillaUtils.h"
#include "NppUtils/ScintillaTypes.h"


class LanguageCommentStyle;

// A comment style defines the comment prefixes that match and the new line
// continuation. A comment prefix is the first word on a comment line. A comment
// style may be either single line or multiline.
// 
// Note that CommentStyle does not refer to the different types of comments
// recognized by the language, but the different comment styles used by
// programmers. For example // and /// are different CommentStyles.
class CommentStyle {
public:
	// Returns true if the comment prefix on the given line matches this style.
	virtual bool matchLine(const std::string_view line) const = 0;

	// Return newline prefix with padding to line up with text on the previous
	// line. If the given line does not match this style then result is
	// undefined.
	virtual std::string getNewlinePrefixWithPadding(const std::string_view line) const;

	// Return true if a comment prefix should be inserted when inserting a new
	// line after the given line.
	virtual bool shouldAutoComment(const LanguageCommentStyle& languageStyle, const Scintilla& scintilla, const LineNumber lineNumber) const = 0;

protected:
	// Return the comment prefix that should be used for newlines of this style.
	virtual const std::string_view getNewlinePrefix(const std::string_view lineWithoutIndent) const = 0;
};

class SingleLine : public CommentStyle {
public:
	SingleLine(const std::string& prefix) : prefix_(prefix) {}

	bool matchLine(const std::string_view line) const override;
	bool shouldAutoComment(const LanguageCommentStyle& languageStyle, const Scintilla& scintilla, const LineNumber lineNumber) const override;

protected:
	const std::string_view getNewlinePrefix(const std::string_view lineWithoutIndent) const override;

	const std::string prefix_;
};

class MultiLine : public CommentStyle {
public:
	MultiLine(const std::string& begin, const std::string& cont, const std::string& end)
		: begin_(begin), continue_(cont), end_(end) {}

	bool matchLine(const std::string_view line) const override;
	bool shouldAutoComment(const LanguageCommentStyle& languageStyle, const Scintilla& scintilla, const LineNumber lineNumber) const override;

protected:
	const std::string_view getNewlinePrefix(const std::string_view line) const override;

private:
	const std::string begin_;
	const std::string continue_;
	const std::string end_;
};

// Defines the set of CommentStyles for a language as well as a set of lexer
// styles corresponding to comments for the language. CommentStyles are tried
// for a match in the order given in the constructor. All language styles have
// an implied no-prefix comment style.
class LanguageCommentStyle {
public:
	// Returns the CommentStyle for the given lexer. Returns nullptr if the
	// lexer is not recognized.
	static LanguageCommentStyle* getLanguageCommentStyle(const Lexer lexer);

	LanguageCommentStyle(absl::flat_hash_set<LRESULT> commentTextStyles, std::vector<const CommentStyle*> commentStyles)
		: commentTextStyles_(std::move(commentTextStyles)), commentStyles_(std::move(commentStyles)) {}

	// Checks if the given line is a comment line that can be wrapped. A comment
	// line can be wrapped if there is no other text (other than whitespace) on
	// the line. Note that empty lines are considered comments for this purpose.
	bool isComment(const Scintilla& scintilla, const LineNumber lineNumber) const;

	// Prefix to insert when creating a new line, based on the comment prefix of
	// the given line. If the comment prefix of the given line is not recognized,
	// returns an empty string. Whitespace between the comment prefix and text
	// on the given line is copied to the new prefix. Additional spaces will be
	// added if the newline prefix is shorter than the given line prefix to ensure
	// text alignment.
	std::string getNewlinePrefix(const Scintilla& scintilla, const LineNumber lineNumber) const;
	std::string getNewlinePrefix(const std::string_view line) const;

	// Checks if the given line should be continued with a new comment line when
	// inserting a newline. This method should be called AFTER the newline is
	// inserted and styled to determine if a prefix should be added.
	bool shouldAutoComment(const Scintilla& scintilla, const LineNumber lineNumber) const;

private:
	const CommentStyle* getCommentStyle(const std::string_view line) const;

	// The styles returned by SCI_GETSTYLEAT or SCI_GETSTYLEDTEXT that correspond to comments for this language.
	const absl::flat_hash_set<LRESULT> commentTextStyles_;
	// Maps the prefix on one line to the prefix that should be used on the next line.
	const std::vector<const CommentStyle*> commentStyles_;
};

#endif COMMENT_H
