#include "LanguageCommentStyle.h"

#include <gtest/gtest.h>

#include "NppUtils/FakeScintilla.h"


const char kComment = 1;

class LanguageCommentStyleTest : public testing::Test
{
protected:
	LanguageCommentStyleTest() : commentStyle_({kComment}, {&tripleSlash, &doubleSlash, &cMultiLine}) {}

	SingleLine doubleSlash{"//"};
	SingleLine tripleSlash{"///"};
	MultiLine cMultiLine{"/*", " *", "*/"};
	LanguageCommentStyle commentStyle_;
};

TEST_F(LanguageCommentStyleTest, TestMatchLine_SingleLine)
{
	EXPECT_FALSE(doubleSlash.matchLine("Some text"));
	EXPECT_TRUE(doubleSlash.matchLine("// Some text"));
}

TEST_F(LanguageCommentStyleTest, TestShouldAutoComment_SingleLine)
{
	FakeScintilla scintilla("\t// Comment line.\n\t\n\t// Comment line.");
	scintilla.setStyledText(0_pos, Position(scintilla.getTextLength()), kComment);

	EXPECT_TRUE(doubleSlash.shouldAutoComment(commentStyle_, scintilla, 0_ln));
	EXPECT_FALSE(doubleSlash.shouldAutoComment(commentStyle_, scintilla, 1_ln));
	EXPECT_FALSE(doubleSlash.shouldAutoComment(commentStyle_, scintilla, 2_ln));
}

TEST_F(LanguageCommentStyleTest, TestGetNewlinePrefixWithPadding_SingleLine)
{
	EXPECT_EQ(doubleSlash.getNewlinePrefixWithPadding("\t// Comment line."), "// ");
}

TEST_F(LanguageCommentStyleTest, TestMatchLine_MultiLine)
{
	EXPECT_TRUE(cMultiLine.matchLine("/* Some text"));
	EXPECT_TRUE(cMultiLine.matchLine(" * Some text"));
}

TEST_F(LanguageCommentStyleTest, TestShouldAutoComment_MultiLine_True)
{
	FakeScintilla scintilla("\t/* Comment line.\n\t\n\t * Comment line.");
	scintilla.setStyledText(0_pos, Position(scintilla.getTextLength()), kComment);

	EXPECT_TRUE(cMultiLine.shouldAutoComment(commentStyle_, scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestShouldAutoComment_MultiLine_False)
{
	FakeScintilla scintilla("\t/* Comment line.*/\n\t\n\tNot a comment line.");
	scintilla.setStyledText(0_pos, 19_pos, kComment);

	EXPECT_FALSE(cMultiLine.shouldAutoComment(commentStyle_, scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestGetNewlinePrefixWithPadding_MultiLine)
{
	EXPECT_EQ(cMultiLine.getNewlinePrefixWithPadding("\t/* Comment line."), " * ");
	EXPECT_EQ(cMultiLine.getNewlinePrefixWithPadding("\t * Comment line."), "* ");
}

TEST_F(LanguageCommentStyleTest, TestIsComment_NotComment) {
	FakeScintilla scintilla("Some Text");

	EXPECT_FALSE(commentStyle_.isComment(scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestIsComment_IsComment)
{
	FakeScintilla scintilla("Some Text");
	scintilla.setStyledText(0_pos, 9_pos, kComment);

	EXPECT_TRUE(commentStyle_.isComment(scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestIsComment_PartialComment)
{
	FakeScintilla scintilla("Some Text");
	scintilla.setStyledText(5_pos, 9_pos, kComment);

	EXPECT_FALSE(commentStyle_.isComment(scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestIsComment_PartialComment2)
{
	FakeScintilla scintilla("Some Text");
	scintilla.setStyledText(0_pos, 4_pos, kComment);

	EXPECT_FALSE(commentStyle_.isComment(scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestIsComment_IndentBeforeComment)
{
	FakeScintilla scintilla("    Some Text");
	scintilla.setStyledText(4_pos, 13_pos, kComment);

	EXPECT_TRUE(commentStyle_.isComment(scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestIsComment_WhitespaceAfterComment)
{
	FakeScintilla scintilla("Some Text   ");
	scintilla.setStyledText(0_pos, 9_pos, kComment);

	EXPECT_TRUE(commentStyle_.isComment(scintilla, 0_ln));
}

TEST_F(LanguageCommentStyleTest, TestGetNewlinePrefix)
{
	EXPECT_EQ(commentStyle_.getNewlinePrefix("//Some Text"), std::string_view("//"));
	EXPECT_EQ(commentStyle_.getNewlinePrefix("// Some Text"), std::string_view("// "));
	EXPECT_EQ(commentStyle_.getNewlinePrefix("/// Some Text"), std::string_view("/// "));
	EXPECT_EQ(commentStyle_.getNewlinePrefix("/* Some Text"), std::string_view(" * "));
	EXPECT_EQ(commentStyle_.getNewlinePrefix("\t    // Some Text"), std::string_view("// "));
	EXPECT_EQ(commentStyle_.getNewlinePrefix("# Some Text"), std::string_view(""));

	FakeScintilla scintilla("// Some text.");
	EXPECT_EQ(commentStyle_.getNewlinePrefix(scintilla, 0_ln), std::string_view("// "));
}
