#include "Wrapper.h"

#include <gtest/gtest.h>

#include "LanguageCommentStyle.h"
#include "NppUtils/FakeScintilla.h"


const char kComment = 1;
const Column kWrapColumn = 16_col;

class WrapperTest : public testing::Test
{
protected:
	WrapperTest() : commentStyle_({kComment}, {&doubleSlash, &cMultiLine}) {}

	SingleLine doubleSlash{"//"};
	MultiLine cMultiLine{"/*", " *", "*/"};
	LanguageCommentStyle commentStyle_;
};

TEST_F(WrapperTest, TestNotComment)
{
	FakeScintilla scintilla("This is not a comment.");

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "This is not a comment.");
}

TEST_F(WrapperTest, TestNoWrap) {
	FakeScintilla scintilla("Comment");
	scintilla.setStyledText(0_pos, 7_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "Comment");
}

TEST_F(WrapperTest, TestWrapNoFollowingLine)
{
	FakeScintilla scintilla("// A long comment.\r\nNot a comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment.\r\nNot a comment.");
}

TEST_F(WrapperTest, TestWrapFollowedByEmptyLine)
{
	FakeScintilla scintilla("// A long comment.\r\n\r\n");
	scintilla.setStyledText(0_pos, 18_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment.\r\n\r\n");
}

TEST_F(WrapperTest, TestWrapEndOfDocument)
{
	FakeScintilla scintilla("// A long comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment.");
}

TEST_F(WrapperTest, TestWrapNoPrefix)
{
	FakeScintilla scintilla("This has no prefix.");
	scintilla.setStyledText(0_pos, 19_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "This has no\r\nprefix.");
}

TEST_F(WrapperTest, TestWrapIntoNextLine)
{
	FakeScintilla scintilla("// A comment with\r\n// lines.");
	scintilla.setStyledText(0_pos, 28_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A comment\r\n// with lines.");
}

TEST_F(WrapperTest, TestWrapMultipleLines)
{
	FakeScintilla scintilla("// A comment with\r\n// two lines.");
	scintilla.setStyledText(0_pos, 32_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A comment\r\n// with two\r\n// lines.");
}

TEST_F(WrapperTest, TestWrapLongWord)
{
	FakeScintilla scintilla("// A wordtoolongtofitononeline.");
	scintilla.setStyledText(0_pos, 31_pos, kComment);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A\r\n// wordtoolongtofitononeline.");
}

TEST_F(WrapperTest, TestWrapOneLineSelection)
{
	FakeScintilla scintilla("// A long comment.\r\nNot a comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);
	scintilla.setAnchor(3_pos);
	scintilla.setCurrentPos(9_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment.\r\nNot a comment.");
}

TEST_F(WrapperTest, TestWrapMultiLineSelection)
{
	// First line wraps into second line, but second line does not wrap. Third
	// line needs to be wrapped.
	FakeScintilla scintilla("// A long comment\r\n// line.\r\n// Another long line.");
	scintilla.setStyledText(0_pos, 50_pos, kComment);
	scintilla.setAnchor(0_pos);
	scintilla.setCurrentPos(50_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment line.\r\n// Another long\r\n// line.");
}

TEST_F(WrapperTest, TestWrapSelectionEndsOnStartOfLine)
{
	// Third line is not wrapped.
	FakeScintilla scintilla("// A long comment\r\n// line.\r\n// Another long line.");
	scintilla.setStyledText(0_pos, 50_pos, kComment);
	scintilla.setAnchor(0_pos);
	scintilla.setCurrentPos(29_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment line.\r\n// Another long line.");
}

TEST_F(WrapperTest, TestWrapMultipleCommentsSelection)
{
	// Two comments separated by code, everything is selected.
	FakeScintilla scintilla("// A long comment.\r\nNot a comment line.\r\n// Another long line.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);
	scintilla.setStyledText(41_pos, 62_pos, kComment);
	scintilla.setAnchor(0_pos);
	scintilla.setCurrentPos(62_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment.\r\nNot a comment line.\r\n// Another long\r\n// line.");
}

TEST_F(WrapperTest, TestWrapNextLineWithoutWhitespace)
{
	FakeScintilla scintilla("// A long comment.\r\n//");
	scintilla.setStyledText(0_pos, 22_pos, kComment);
	scintilla.setCurrentPos(18_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getData(), "// A long\r\n// comment.\r\n//");
}

TEST_F(WrapperTest, TestUpdatePosition_BeforeWrap)
{
	FakeScintilla scintilla("// A long comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);
	scintilla.setCurrentPos(9_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 9_pos);
}

TEST_F(WrapperTest, TestUpdatePosition_WhitespaceBeforeWrap)
{
	FakeScintilla scintilla("// A long  comment.");
	scintilla.setStyledText(0_pos, 19_pos, kComment);
	scintilla.setCurrentPos(10_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 14_pos);
}

TEST_F(WrapperTest, TestUpdatePosition_InWrappedText)
{
	FakeScintilla scintilla("// A long comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);
	scintilla.setCurrentPos(13_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 17_pos);
}

TEST_F(WrapperTest, TestUpdatePosition_EndOfText)
{
	FakeScintilla scintilla("// A long comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);
	scintilla.setCurrentPos(18_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 22_pos);
}

TEST_F(WrapperTest, TestUpdatePosition_InTrailingWhitespace)
{
	FakeScintilla scintilla("// A long comment. ");
	scintilla.setStyledText(0_pos, 19_pos, kComment);
	scintilla.setCurrentPos(19_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 22_pos);
}

TEST_F(WrapperTest, TestUpdatePosition_AfterWrappedTextInComment)
{
	FakeScintilla scintilla("// A long comment.\r\n// More.");
	scintilla.setStyledText(0_pos, 28_pos, kComment);
	scintilla.setCurrentPos(20_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 27_pos);
}

TEST_F(WrapperTest, TestUpdatePosition_AfterWrappedTextNoComment)
{
	FakeScintilla scintilla("// A long comment.\r\n\tNot a comment.");
	scintilla.setStyledText(0_pos, 18_pos, kComment);
	scintilla.setCurrentPos(20_pos);

	Wrapper wrapper(scintilla, &commentStyle_, kWrapColumn);
	wrapper.wrapSelection();
	EXPECT_EQ(scintilla.getCurrentPos(), 24_pos);
}
