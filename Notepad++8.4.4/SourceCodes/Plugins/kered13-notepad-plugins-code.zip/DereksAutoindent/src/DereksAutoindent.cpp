#include "DereksAutoindent.h"

#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string_view>

#include "NppUtils/NPP/Scintilla.h"
#include "NppUtils/NppUtilsImpl.h"
#include "NppUtils/ScintillaTypes.h"


std::unique_ptr<NppUtils> gNppUtils;
std::unique_ptr<DereksAutoindent> gPlugin;

BOOL APIENTRY DllMain(HANDLE hModule, DWORD  reasonForCall, LPVOID lpReserved) {
	switch(reasonForCall) {
		case DLL_PROCESS_ATTACH:
			break;

		case DLL_PROCESS_DETACH:
			// Delete plugin and trigger cleanup.
			gPlugin = nullptr;
			gNppUtils = nullptr;
			break;

		case DLL_THREAD_ATTACH:
			break;

		case DLL_THREAD_DETACH:
			break;
	}

	return TRUE;
}

extern "C" __declspec(dllexport) void setInfo(NppData nppData) {
	gNppUtils = std::make_unique<NppUtilsImpl>(nppData);
	gPlugin = std::make_unique<DereksAutoindent>(nppData, *gNppUtils);
}

extern "C" __declspec(dllexport) const wchar_t* getName() {
	return DereksAutoindent::kPluginName_;
}

extern "C" __declspec(dllexport) FuncItem * getFuncsArray(int* nbF) {
	std::vector<FuncItem>& funcItems = gPlugin->getFuncItems();
	*nbF = (int)funcItems.size();
	return funcItems.data();
}

bool fireEnter;
bool curlyBrace;

extern "C" __declspec(dllexport) void beNotified(SCNotification *notifyCode) {
	switch(notifyCode->nmhdr.code) {
		case SCN_CHARADDED:
		{
			if(notifyCode->ch == '\n') {
				gPlugin->newline();
			} else if(notifyCode->ch == '}') {
				// Styling must be completed for brace matching to work
				// correctly, so wait for UI update.
				curlyBrace = true;
			}
			break;
		}
		case SCN_UPDATEUI:
		{
			if(curlyBrace) {
				gPlugin->indentEndingCurlyBrace();
				curlyBrace = false;
			}
			break;
		}
	}
}

// Here you can process the Npp Messages 
// I will make the messages accessible little by little, according to the need of plugin development.
// Please let me know if you need to access to some messages :
// http://sourceforge.net/forum/forum.php?forum_id=482781
//
extern "C" __declspec(dllexport) LRESULT messageProc(UINT Message, WPARAM wParam, LPARAM lParam) {/*
	if (Message == WM_MOVE)
	{
		::MessageBox(nullptr, "move", "", MB_OK);
	}
*/
	return true;
}

extern "C" __declspec(dllexport) BOOL isUnicode() {
	return true;
}


//
// Helper functions.
//
std::string_view::iterator skipBlockComment(std::string_view::iterator p, const std::string_view::iterator end) {
	for(; p != end; p++) {
		const char c = *p;
		if(c == '*') {
			// Look ahead for possible end comment.
			if(p + 1 == end) {
				return end;
			} else if(*(p + 1) == '/') {
				return p + 2;
			}
		}
	}
	return end;
}

std::string_view::iterator skipQuoted(const char quote, std::string_view::iterator p, const std::string_view::iterator end) {
	for(; p != end; p++) {
		const char c = *p;
		if(c == '\\') {
			// Next character is escaped, so ignore it if it is not null.
			if(p + 1 == end) {
				return end;
			} else {
				p++;
			}
		} else if(c == quote) {
			return p + 1;
		}
	}
	return p;
}

// Returns the next character that is not part of a comment or quote.
std::string_view::iterator nextNotCommentsOrQuotes(std::string_view::iterator p, std::string_view::iterator end) {
	while(p != end) {
		const char c = *p;
		switch(c) {
			case '/':
				if(p + 1 == end) {
					return end;
				}
				// Look ahead for possible comments.
				switch(*(p + 1)) {
					case '/':
						// Line comment, ignore the rest of the line.
						return end;
					case '*':
						// Handle block coomment.
						p = skipBlockComment(p + 2, end);
						break;
					default:
						p++;
						break;
				}
				break;
			case '"':
				p = skipQuoted('"', p + 1, end);
				break;
			case '\'':
				p = skipQuoted('\'', p + 1, end);
				break;
			default:
				return p;
		}
	}
	return end;
}

bool hasUnclosedOpen(const std::string_view line) {
	int count = 0;

	for(auto p = nextNotCommentsOrQuotes(line.begin(), line.end());
		p != line.end();
		p = nextNotCommentsOrQuotes(p + 1, line.end())) {
		const char c = *p;
		switch(c) {
			case '{':
				count++;
				break;
			case '}':
				if(count > 0) {
					count--;
				}
				break;
			default:
				break;
		}
	}
	return count > 0;
}

bool hasUnopenedClose(const std::string_view line) {
	int count = 0;

	for(auto p = nextNotCommentsOrQuotes(line.begin(), line.end());
		p != line.end();
		p = nextNotCommentsOrQuotes(p + 1, line.end())) {
		const char c = *p;
		switch(c) {
			case '{':
				count++;
				break;
			case '}':
				count--;
				break;
			default:
				break;
		}
		if(count < 0) {
			return true;
		}
	}
	return false;
}

std::optional<DPosition> findLastChar(const std::string_view line, const char c) {
	std::optional<DPosition> last = std::nullopt;
	for(auto p = nextNotCommentsOrQuotes(line.begin(), line.end());
	    p != line.end();
	    p = nextNotCommentsOrQuotes(p + 1, line.end())) {
		if(c == *p) {
			last = DPosition(std::distance(line.begin(), p));
		}
	}
	return last;
}

Position copyIndent(Scintilla& scintilla, const LineNumber source, const LineNumber dest) {
	return scintilla.setLineIndent(dest, scintilla.getLineIndent(source));
}


DereksAutoindent::DereksAutoindent(const NppData& nppData, NppUtils& nppUtils) :
	NppPlugin(wstringToString(kPluginName_), nppData, nppUtils) {
	//---------------------------//
	//-- STEP 3. READ SETTINGS --//
	//---------------------------//
	autoindentEnabled_ = readSetting<bool>("EnableAutoindent");

	//--------------------------------------------//
	//-- STEP 4. CUSTOMIZE YOUR PLUGIN COMMANDS --//
	//--------------------------------------------//
	nppMenu_.addItem("About", std::bind(&DereksAutoindent::showAbout, this));
	nppMenu_.addToggleItem("Enable autoindent", autoindentEnabled_, nppData_);
}

DereksAutoindent::~DereksAutoindent() {
	//----------------------------//
	//-- STEP 5. WRITE SETTINGS --//
	//----------------------------//
	writeSetting<bool>("EnableAutoindent", autoindentEnabled_);
}

void DereksAutoindent::showAbout() {
	std::wstring aboutMessage =
		L"Derek's Autoindent:\n"
		L"\n"
		L"This plugin implements autoindent behavior mimicing that of Textpad or Notepad#.";
	MessageBox(nppData_._nppHandle, aboutMessage.c_str(), L"Derek's Autoindent", MB_OK);
}

void DereksAutoindent::newline() {
	const std::shared_ptr<Scintilla> scintilla = nppUtils_.getCurrentScintilla();
	if(!autoindentEnabled_ || !scintilla || !acceptLang(nppUtils_.getCurrentLangType())) {
		return;
	}

	const LineNumber lineNumber = scintilla->getCurrentLineNumber();
	autoIndent(*scintilla, lineNumber);
}

void DereksAutoindent::autoIndent(Scintilla& scintilla, const LineNumber lineNumber) {
	const auto undo = scintilla.getUndoAction();

	const DColumn tabSize = scintilla.getTabWidth();
	// Indentation from previous line.
	const Column indent = scintilla.getLineIndentation(lineNumber - 1_dln);
	// Check for curly braces to increase indentation.
	if(hasUnclosedOpen(scintilla.getLine(lineNumber - 1_dln))) {
		// If we split a pair of braces add a new line for the closing brace
		// and indent it to match the previous line.
		std::string line = scintilla.getLineWithoutIndent(lineNumber);
		if(hasUnopenedClose(line)) {
			// Find position of last closing brace. It is guaranteed to exist
			// because of the condition above.
			Position newlineInsertPos = scintilla.getCurrentPos() + *findLastChar(line, '}');
			scintilla.insertText(newlineInsertPos, scintilla.getEol());
			copyIndent(scintilla, lineNumber - 1_dln, lineNumber + 1_dln);
		}
		const Column newIndent = indent + tabSize;
		const Position position = scintilla.setLineIndentation(lineNumber, newIndent);
		scintilla.gotoPos(position);
	} else {
		// Copy previous indent exactly, not just the column.
		const Position position = copyIndent(scintilla, lineNumber - 1_dln, lineNumber);
		scintilla.gotoPos(position);
	}
	scintilla.chooseCaretX();
}

void DereksAutoindent::indentEndingCurlyBrace() {
	if(!autoindentEnabled_ || !acceptLang(nppUtils_.getCurrentLangType())) {
		return;
	}

	const std::shared_ptr<Scintilla> scintilla = nppUtils_.getCurrentScintilla();
	if(!scintilla) {
		return;
	}

	const Position position = scintilla->getCurrentPos();
	const LineNumber lineNumber = scintilla->lineFromPosition(position);

	const std::string line = scintilla->getLineWithoutIndent(lineNumber);
	// Abort if there are other characters on the line.
	if(line.size() > 0 && line[0] != '}') {
		return;
	}

	// Get opening brace indentation.
	const Position openingBracePosition = Position(scintilla->sendMessage(SCI_BRACEMATCH, *position - 1));
	if(openingBracePosition == Position(-1)) {
		return;
	}
	const LineNumber openingBraceLine = scintilla->lineFromPosition(openingBracePosition);
	const Column braceIndent = scintilla->getLineIndentation(openingBraceLine);

	// Set the closing brace indentation.
	const auto undo = scintilla->getUndoAction();
	scintilla->setLineIndentation(lineNumber, braceIndent);
}

bool DereksAutoindent::acceptLang(const LangType lang) {
	switch(lang) {
		case LangType::L_C:
		case LangType::L_COFFEESCRIPT:
		case LangType::L_CPP:
		case LangType::L_CS:
		case LangType::L_CSS:
		case LangType::L_D:
		case LangType::L_JAVA:
		case LangType::L_JAVASCRIPT:
		case LangType::L_JS:
		case LangType::L_JSON:
		case LangType::L_PERL:
		case LangType::L_PHP:
		case LangType::L_POWERSHELL:
		case LangType::L_RUST:
		case LangType::L_SWIFT:
		case LangType::L_USER:
			return true;
		default:
			return false;
	}
}