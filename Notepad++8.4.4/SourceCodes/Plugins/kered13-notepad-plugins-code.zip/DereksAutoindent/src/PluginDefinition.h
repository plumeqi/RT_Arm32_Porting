//this file is part of notepad++
//Copyright (C)2003 Don HO <donho@altern.org>
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#ifndef PLUGINDEFINITION_H
#define PLUGINDEFINITION_H

//
// All definitions of plugin interface
//
#include "NPP/PluginInterface.h"

#include "NppMenu.h"
#include "NppPlugin.h"
#include "ScintillaImpl.h"

//-------------------------------------//
//-- STEP 1. DEFINE YOUR PLUGIN NAME --//
//-------------------------------------//
// Here define your plugin name
//
#ifdef _DEBUG
const TCHAR NPP_PLUGIN_NAME[] = TEXT("Derek's Autoindent Debug");
#else
const TCHAR NPP_PLUGIN_NAME[] = TEXT("Derek's Autoindent");
#endif

class DereksAutoindent : public NppPlugin
{
public:
	DereksAutoindent(const NppData& nppData);
	~DereksAutoindent();

	void newline();
	void indentEndingCurlyBrace();

private:
	bool autoindentEnabled_;

	void showAbout();
	void autoIndent(Scintilla& scintilla, const linenumber_t lineNumber);
	int countCurlyBraces(const std::string_view line);
	// TODO: Remove these from the class.
	std::string_view::iterator skipBlockComment(std::string_view::iterator p, const std::string_view::iterator end);
	std::string_view::iterator skipQuoted(const char quote, std::string_view::iterator p, const std::string_view::iterator end);
	bool acceptLang(const int lang);
};

#endif //PLUGINDEFINITION_H
