#ifndef DEREKS_AUTOINDENT_H
#define DEREKS_AUTOINDENT_H

#include "NppUtils/NPP/Notepad_plus_msgs.h"
#include "NppUtils/NppPlugin.h"
#include "NppUtils/NppUtils.h"
#include "NppUtils/ScintillaUtils.h"


class DereksAutoindent : public NppPlugin {
public:
	//-------------------------------------//
	//-- STEP 1. DEFINE YOUR PLUGIN NAME --//
	//-------------------------------------//
	static constexpr wchar_t kPluginName_[] = L"Derek's Autoindent";

	// Initialize your plugin data and commands here.
	DereksAutoindent(const NppData& nppData, NppUtils& nppUtils);

	// Here you can do the clean up, save the parameters (if any) for the next session
	~DereksAutoindent();

	//------------------------------------------//
	//-- STEP 2. DEFINE YOUR PLUGIN FUNCTIONS --//
	//------------------------------------------//
	void newline();
	void indentEndingCurlyBrace();

private:
	void autoIndent(Scintilla& scintilla, const LineNumber lineNumber);
	void showAbout();
	bool acceptLang(const LangType lang);

	bool autoindentEnabled_;
};

#endif //DEREKS_AUTOINDENT_H