## _GoToLineCol_ in Darkmode

Darkmode for the _GoToLineCol_ plugin is rendered using the [NPP_Plugin_Darkmode](https://github.com/shriprem/NPP_Plugin_Darkmode) wrapper class.

### Plugin Panel in dark mode (_in Cyan tone_)
![GotoLineCol Panel](https://raw.githubusercontent.com/shriprem/Goto-Line-Col-NPP-Plugin/master/images/PanelBytePos_dm.png)

### Preferences Dialog in dark mode (_in Green tone_)
![Preferences](https://raw.githubusercontent.com/shriprem/Goto-Line-Col-NPP-Plugin/master/images/Preferences_dm.png)

