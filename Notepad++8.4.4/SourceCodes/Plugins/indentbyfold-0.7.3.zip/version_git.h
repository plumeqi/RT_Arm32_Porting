#pragma once 
#define VERSION_GIT_STR "UNKNOWN" 
#define VERSION_GIT_WSTR L"UNKNOWN" 
