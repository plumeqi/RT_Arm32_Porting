#ifndef RESOURCE_H
#define RESOURCE_H

#ifndef IDC_STATIC 
#define IDC_STATIC -1
#endif

#endif
