IndentByFold
============

Notepad++ Auto indent based on the fold level plug-in

The project page is at https://github.com/ffes/indentbyfold/

The documentation of this plug-in can be found at [Read The Docs](https://indentbyfold.readthedocs.io/).

This includes:
- Instructions [how to build](https://indentbyfold.readthedocs.io/en/latest/building.html)
- A complete [release history](https://indentbyfold.readthedocs.io/en/latest/history.html)
