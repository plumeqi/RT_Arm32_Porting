Contact
=======

The plug-in's web page can be found at https://github.com/ffes/indentbyfold/.
The downloads and issue tracker can be found there as well.

If you have problems with, questions about or suggestions for IndentByFold
and you want to contact me directly, you can send me an email at
fesevur@gmail.com
