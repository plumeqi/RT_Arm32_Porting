.. IndentByFold documentation master file

**************************************
Welcome to IndentByFold documentation!
**************************************

Contents:

.. toctree::
    :maxdepth: 2

    introduction.rst
    faq.rst
    building.rst
    wishlist.rst
    contact.rst
    license.rst
    history.rst
    gpl-2.rst

******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
