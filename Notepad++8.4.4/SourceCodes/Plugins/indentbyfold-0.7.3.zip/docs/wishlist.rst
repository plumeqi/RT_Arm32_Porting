Wish list
=========

-  Reindent a selection.

-  Integrate Python Ident plugin

-  Check if the ``Auto Indent`` checkbox in the Notepad++ settings has been
   unchecked. Use TinyXml2 to parse the ``config.xml`` file and check
   ``<GUIConfig name="MaitainIndent">``.

-  Maybe add a menu item to see if the plug-in is active. Depends on checking
   the ``Auto Indent`` checkbox.

-  Sometimes the plug-in changes a file after opening it. Not sure when that
   happens exactly.
