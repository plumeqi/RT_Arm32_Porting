License
=======

This plug-in is published under the GPL-2 license. See :ref:`gpl-2` for the full
license agreement. You can find the sources of the latest version or
the lastest developments at `GitHub`_.

.. _GitHub: https://github.com/ffes/indentbyfold
