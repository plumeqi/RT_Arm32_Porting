// This file is part of DoxyIt.
// 
// Copyright (C)2013 Justin Dailey <dail8859@yahoo.com>
// 
// DoxyIt is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either
// version 2 of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#ifndef PLUGINDEFINITION_H
#define PLUGINDEFINITION_H

#include <sstream>
#include "PluginInterface.h"
#include "ScintillaEditor.h"

const wchar_t NPP_PLUGIN_NAME[] = TEXT("DoxyIt");
const int nbFunc = 7;

// --- Helper functions ---

extern ScintillaEditor editor;

LRESULT SendNpp(UINT Msg, WPARAM wParam=SCI_UNUSED, LPARAM lParam=SCI_UNUSED);

// Calls from DoxyIt.cpp
void pluginInit(HANDLE hModule);						// Called from DllMain, DLL_PROCESS_ATTACH
void pluginCleanUp();									// Called from DllMain, DLL_PROCESS_DETACH
void setNppInfo(NppData notepadPlusData);				// Called from setInfo()
void handleNotification(SCNotification *notifyCode);	// Called from beNotified()

#endif //PLUGINDEFINITION_H
