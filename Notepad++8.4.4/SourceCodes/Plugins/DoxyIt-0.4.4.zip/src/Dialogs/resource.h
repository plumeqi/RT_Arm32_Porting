#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_SETTINGSDLG                         101
#define IDD_ABOUTDLG                            103
#define IDD_NEWLANG                             105
#define IDC_SETTINGS_HELP                       1000
#define IDC_EDIT_PREFIX                         1001
#define IDC_GITHUB                              1001
#define IDC_EDIT_FORMAT                         1002
#define IDC_EDIT_LANG                           1002
#define IDC_VERSION                             1002
#define IDC_README                              1003
#define IDC_RAD_FUNCTION                        1004
#define IDC_BTN_REMOVE                          1006
#define IDC_CMB_LANG                            1007
#define IDC_EDIT_START                          1008
#define IDC_EDIT_LINE                           1009
#define IDC_EDIT_END                            1010
#define IDC_EDIT_PREVIEW                        1011
#define IDC_BTN_ADD                             1012
#define IDC_CHB_ALIGN                           1013
#define IDC_RAD_FILE                            1014
