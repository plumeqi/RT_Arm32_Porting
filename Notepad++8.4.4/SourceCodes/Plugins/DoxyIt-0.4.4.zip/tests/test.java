// Most of the features of the parser have been tested in test.c
// Now just test Java specific features

public static void main(String[] args)

// Thats about it for now...
