// Most of the features of the parser have been tested in test.c
// Now just test C# specific features

void PassRef(ref int x)

void PassOut(out int x)

void PrintAll(IEnumerable<object> objects, string! input)
