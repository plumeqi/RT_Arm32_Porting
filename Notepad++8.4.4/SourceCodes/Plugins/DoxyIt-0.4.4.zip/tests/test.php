<?php 
// Most of the features of the parser have been tested in test.c
// Now just test PHP specific features

function myFunction($abc, $def = "test")

function get_user_name($uid='',$type='username',$key='sub')

// Thats about it for now...
?>
