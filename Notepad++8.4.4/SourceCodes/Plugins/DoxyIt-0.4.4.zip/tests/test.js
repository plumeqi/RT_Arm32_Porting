// Most of the features of the parser have been tested in test.c
// Now just test Java specific features

function myFunction(abc, def, ghi)

a.b.c = function(jkl, mno)
