# --- Test function names ---

def f()

deff f()    # fail

def f1_abc()

# --- Test parameter values ---

def foo(bar)

def foo(bar = baz)

def __init__(self, x, y, z)

def f(x, *args, **kwargs)

# Lots more could be added
