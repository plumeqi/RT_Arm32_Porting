//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� LNhistory.rc ʹ��
//
#define IDB_BITMAP1                     108
#define IDB_BITMAP2                     109
#define IDB_BITMAP3                     110
#define IDB_BITMAP4                     111
#define IDI_ICON1                       112
#define IDC_LOC_LIST                    1001
#define IDC_STATIC_ABOUT                1003
#define IDC_CHECK1                      1004
#define IDC_CHECK_AUTO                  1004
#define IDC_BUTTON_CLEAR                1005
#define IDC_CHECK_ALWAYS                1006
#define IDC_CHECK_SAVERECORD            1007
#define IDC_CHECK_INCURR                1008
#define IDC_CHECK_MARK                  1010
#define ID_STATIC_COLOR                 1011
#define IDC_CHECK_BOOKMARK              1012
#define ID_STATIC_SAVECOLOR             1013
#define IDD_LOCATIONNAVIGATE            2500
#define ID_LNHISTORY_EDIT               2501
#define ID_LNHISTORY_EDIT2              2502
#define ID_UGO_STATIC                   2505
#define ID_UGO_STATIC2                  2506

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
