#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_ABOUTDLG                            101
#define IDC_GITHUB                              1000
#define IDC_VERSION                             1001
#define IDC_README                              1002
