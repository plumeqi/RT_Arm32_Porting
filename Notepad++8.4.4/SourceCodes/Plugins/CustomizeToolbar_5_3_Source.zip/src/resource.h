//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDI_AUTO_WORDCOMPLETE           101
#define IDI_BLANK_SPACETOTAB            102
#define IDI_BLANK_TABTOSPACE            103
#define IDI_BLANK_TRIMTRAILING          104
#define IDI_BOOKMARK_CLEAR              105
#define IDI_BOOKMARK_NEXT               106
#define IDI_BOOKMARK_PREV               107
#define IDI_CLONE_CLONETOOTHER          108
#define IDI_COMMENT_CLEAR               109
#define IDI_COMMENT_SET                 110
#define IDI_CUSTOM_FAILEDMATCH          111
#define IDI_CUSTOM_MISSINGFILE          112
#define IDI_CUSTOMIZE_TOOLBAR           113
#define IDI_EDIT_DELETE                 114
#define IDI_FILE_CLOSEALLBUT            115
#define IDI_INDENT_DECREASE             116
#define IDI_INDENT_INCREASE             117
#define IDI_LINE_DUPLICATE              118
#define IDI_MOVE_MOVETOOTHER            119
#define IDI_SEARCH_FINDINFILES          120
#define IDI_SEARCH_FINDNEXT             121
#define IDI_SEARCH_FINDPREV             122
#define IDI_SEARCH_GOTO                 123
#define IDI_SEARCH_INCREMENTAL          124
#define IDI_SEARCH_RESULTS              125
#define IDI_VIEW_FOLDALL                126
#define IDI_VIEW_HIDELINES              127
#define IDI_VIEW_UNFOLDALL              128
#define IDI_ZOOM_RESTORE                129
#define IDB_AUTO_WORDCOMPLETE           130
#define IDB_BLANK_SPACETOTAB            131
#define IDB_BLANK_TABTOSPACE            132
#define IDB_BLANK_TRIMTRAILING          133
#define IDB_BOOKMARK_CLEAR              134
#define IDB_BOOKMARK_NEXT               135
#define IDB_BOOKMARK_PREV               136
#define IDB_CLONE_CLONETOOTHER          137
#define IDB_COMMENT_CLEAR               138
#define IDB_COMMENT_SET                 139
#define IDB_CUSTOM_BACKGROUND16         140
#define IDB_CUSTOM_BACKGROUND32         141
#define IDB_CUSTOM_MISSINGFILE          142
#define IDB_CUSTOMIZE_TOOLBAR           143
#define IDB_EDIT_DELETE                 144
#define IDB_FILE_CLOSEALLBUT            145
#define IDB_INDENT_DECREASE             146
#define IDB_INDENT_INCREASE             147
#define IDB_LINE_DUPLICATE              148
#define IDB_MOVE_MOVETOOTHER            149
#define IDB_SEARCH_FINDINFILES          150
#define IDB_SEARCH_FINDNEXT             151
#define IDB_SEARCH_FINDPREV             152
#define IDB_SEARCH_GOTO                 153
#define IDB_SEARCH_INCREMENTAL          154
#define IDB_SEARCH_RESULTS              155
#define IDB_VIEW_FOLDALL                156
#define IDB_VIEW_HIDELINES              157
#define IDB_VIEW_UNFOLDALL              158
#define IDB_ZOOM_RESTORE                159

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
