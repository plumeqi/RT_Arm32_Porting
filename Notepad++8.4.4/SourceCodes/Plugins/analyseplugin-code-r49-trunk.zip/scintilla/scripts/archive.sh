# Up to parent directory of scintilla
cd ../..

# Archive Scintilla to scintilla.tgz
hg archive --repository scintilla scintilla.tgz
