Text=0
Line end characters=1
**Strong Emphasis (bold) 1=2**
__Strong Emphasis (bold) 2=3__
*Emphasis (italic) 1=4*
_Emphasis (italic) 2=5_
# Heading level 1=6
## Heading level 2=7
### Heading level 3=8
#### Heading level 4=9
##### Heading level 5=10
###### Heading level 6=11
   PreChar=12
* Unordered list item=13
1. Ordered list item=14
>Block Quote=15
~~Strike-out=16~~

***
Previous line was horizontal rule=17
[Link=18](https://18.com)
`Inline Code=19`
``Inline Code=20``

~~~
Block code=21
~~~

## Issue 23
`