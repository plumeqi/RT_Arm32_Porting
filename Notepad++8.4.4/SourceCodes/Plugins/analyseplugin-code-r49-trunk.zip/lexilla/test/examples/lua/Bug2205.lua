print("First")
--[[ Block comment start
print("Second")
--[[ Another block comment ]]
print("Third. If run through an actual program, this will be executed.")
