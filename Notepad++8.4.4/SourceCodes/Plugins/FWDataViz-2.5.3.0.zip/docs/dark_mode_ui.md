## _FWDataViz_ in Darkmode

Darkmode for the _FWDataViz_ plugin is rendered using the [NPP_Plugin_Darkmode](https://github.com/shriprem/NPP_Plugin_Darkmode) wrapper class.

### Plugin Panel in dark mode (_in Olive tone_)
![Plugin_Panel](https://raw.githubusercontent.com/shriprem/FWDataViz/master/images/plugin_panel_dm.png)

### FileType Dialog in dark mode (_in Cyan tone_)
![FileType_Config](https://raw.githubusercontent.com/shriprem/FWDataViz/master/images/file_type_editor_dm.png)
