## Append Visualizer Theme Data

![Theme_Extract](https://raw.githubusercontent.com/shriprem/FWDataViz/master/images/color_theme_append.png)

Useful for importing customized Theme definitions within teams, and between collaborators.

**Tip:** You can import more than one Theme definition at a time from a consolidated file.

**See also**: [Extract Visualizer Theme Data](https://github.com/shriprem/FWDataViz/blob/master/docs/theme_extract_dialog.md)
