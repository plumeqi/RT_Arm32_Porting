#ifndef SETTINGSDLG_H_
#define SETTINGSDLG_H

void doSettings();

#endif
