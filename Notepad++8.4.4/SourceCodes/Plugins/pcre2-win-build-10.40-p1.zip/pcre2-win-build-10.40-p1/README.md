# pcre2-win-build

pcre2 Windows build with Visual Studio.

This version is pcre2-10.40.

To build, simply open the required solution file, and
you know how to use Visual Studio, right?
(or perhaps this is the wrong place for you.)
