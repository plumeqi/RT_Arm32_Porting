#include "nppDarkMode.h"

namespace NppDarkMode
{

	void setDarkTitleBar(HWND /*hwnd*/)
	{
	}

	void setDarkTooltips(HWND /*hwnd*/, ToolTipsType /*type*/)
	{
	}

}
