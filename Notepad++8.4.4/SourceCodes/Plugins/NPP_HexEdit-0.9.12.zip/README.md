# NPP_HexEdit
Notepad++ Plugin Hexedit

This is an unofficial repo with source code from:  
https://sourceforge.net/projects/npp-plugins/files/Hex%20Editor/


Build Status
------------

AppVeyor `VS2019`  [![Build status](https://ci.appveyor.com/api/projects/status/x8j5dnfur93n6six?svg=true)](https://ci.appveyor.com/project/chcg/npp-hexedit)

Related repos on GitHub:
- https://github.com/JetNpp/HexEditor
- https://github.com/mackwai/NPPHexEditor
