What does this program:

This sources contains a dockable function list for Notepad++ version 4.0.
With this plugin you could easy browse between functions in a file.

For generating the dll file use VC++ 6. The project is included.

If you create a new project for VC 7/8 or MinGW please sent me the
complete project. I will integrate it.


The plugins side is:
https://sourceforge.net/projects/npp-plugins

Have fun

Jens Lorenz
jens.plugin.npp@gmx.de
