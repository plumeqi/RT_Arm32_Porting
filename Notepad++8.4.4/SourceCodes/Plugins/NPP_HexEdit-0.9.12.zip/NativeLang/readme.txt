What does this program:

This plugin changes the Notepad++ plugins dialog into other languages.

Preconditions:
Merged NativeLang.ini file in the Notepad++ plugins config folder.

Currently following plugins are supported:
Explorer.dll
SpellChecker.dll
WindowManager.dll

Download the sources of each plugin to get the template NativeLang.ini file.
NativeLang_template.ini should be stored in <plugin>\lang


The plugins side is:
http://sourceforge.net/projects/npp-plugins/


For further information, how to change the languages in other plugins look
into repository NativeLang\doc\


Have fun

