
Base icons from:

http://www.famfamfam.com


Modifications from:

Jens Lorenz
jens.plugin.npp@gmx.de
