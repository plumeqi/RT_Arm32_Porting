What does this program:

This sources contains a dockable explorer plugin for Notepad++ version 4.0.
With this plugin you could easy browse through files and edit sources in
Notepad.

For generating the dll file use VC++ 6. The project is included.

If you create a new project for VC 7/8 or MinGW please sent me the
complete project. I will integrate it.


The plugins side is:
http://npp-explorer.sourceforge.net/

Have fun

Jens Lorenz
jens.plugin.npp@gmx.de
