/// GitHub Issue #35
fn main() {}
/*