fn main() {
    let a: i128 = 42i128;
    let b: u128 = 1337u128;
    println!("{} + {} = {}", a, b, (a as u128) + b);
}
