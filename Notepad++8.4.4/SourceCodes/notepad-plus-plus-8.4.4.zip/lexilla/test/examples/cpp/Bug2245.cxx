int i;
#if 1
i=1;
#
i=2;
#else
i=3;
#endif
i=4;
#elif 1
i=5;
#else
i=6;
