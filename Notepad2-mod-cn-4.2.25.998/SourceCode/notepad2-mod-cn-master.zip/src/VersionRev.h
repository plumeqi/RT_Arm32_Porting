#pragma once

#define VERSION_HASH _T("a5ce802")
#define VERSION_REV 998
#define VERSION_REV_FULL _T("998 (a5ce802)")
