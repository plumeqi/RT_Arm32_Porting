
/* This file is part of The New Aspell
 * Copyright (C) 2001 by Nicolas Hatier under the GNU LGPL
 * license version 2.0 or 2.1.  You should have received a copy of the
 * LGPL license along with this library if you did not you can find it
 * at http://www.gnu.org/.                                              */

/* minimalist pthread for windows - supporting only Mutexes as required
   by aspell */


typedef void * pthread_mutex_t;

int pthread_mutex_init(pthread_mutex_t *, const void **);
int pthread_mutex_destroy(pthread_mutex_t *);
int pthread_mutex_lock (pthread_mutex_t *);
int pthread_mutex_unlock (pthread_mutex_t *);
