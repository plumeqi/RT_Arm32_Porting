
/* This file is part of The New Aspell
 * Copyright (C) 2001 by Nicolas Hatier under the GNU LGPL
 * license version 2.0 or 2.1.  You should have received a copy of the
 * LGPL license along with this library if you did not you can find it
 * at http://www.gnu.org/.                                              */

/* minimalist pthread for windows - supporting only Mutexes as required
   by aspell */


#include "pthread.h"
#include <windows.h>

int pthread_mutex_init(pthread_mutex_t * o_mutex, const void ** in_unused)
{
   void * l_temp = CreateMutexA(0, 0, 0);

   if (!l_temp)
      return 1;

   *o_mutex = l_temp;
   return 0;
}

int pthread_mutex_destroy(pthread_mutex_t *mutex)
{
   CloseHandle(*mutex);
   return 0;
}

int pthread_mutex_lock (pthread_mutex_t * mutex)
{
   return WaitForSingleObject(*mutex, 0xFFFFFFFF);
}

int pthread_mutex_unlock (pthread_mutex_t * mutex)
{
   return !ReleaseMutex(*mutex);
}
