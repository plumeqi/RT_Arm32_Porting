#ifndef _WIN32_DIRENT_H
#define _WIN32_DIRENT_H

// This file is part of The New Aspell
// Copyright (C) 2001, 2006 Free Software Foundation, Inc. 
// under the GNU LGPL license version 2.0 or 2.1.  
// You should have received a copy of the LGPL
// license along with this library if you did not you can find
// it at http://www.gnu.org/.

// Copyright (C) 2007 by Nicolas Hatier under the same terms

#include <sys/types.h>

struct dirent
{
  char d_name[256];
};

typedef void DIR; 

DIR    * opendir  (const char * name);
dirent * readdir  (DIR * dir);
int      closedir (DIR * dir);

#endif /* SCM_WIN32_DIRENT_H */
