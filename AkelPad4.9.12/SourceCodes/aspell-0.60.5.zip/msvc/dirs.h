#define PREFIX "."
#define DATA_DIR "<prefix>/data"
#define DICT_DIR "<prefix>/dict"
#define CONF_DIR "<prefix>"
