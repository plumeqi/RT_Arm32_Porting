//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by akelpad.rc
//
#define IDI_ICON1                       1
#define IDD_FIND                        1
#define IDM_APPMENU                     1
#define IDM_POPUP                       2
#define IDD_REPLACE                     2
#define IDD_CONFIRM                     3
#define IDD_SELECTCODEPAGE              4
#define IDD_ABOUT                       5
#define IDD_GOTOLINE                    6
#define IDC_ALL                         9
#define IDC_STATICTEXT1                 101
#define IDC_CODEPAGE                    101
#define IDC_TEXT                        101
#define IDC_ESCAPESEQ                   102
#define IDC_MATCHCASE                   103
#define IDC_WHOLEWORDS                  104
#define IDC_WHOLEWORD                   104
#define IDC_BACKWARD                    105
#define IDC_NEWTEXT                     108
#define IDC_ABOUT_EMAIL                 1000
#define IDC_ABOUT_ICQ                   1001
#define IDC_GOTOLINE                    1002
#define IDC_HOMEPAGE                    1003
#define IDC_INSEL                       1004
#define IDM_SETTINGS_BG                 40001
#define IDM_SETTINGS_FONT               40002
#define IDM_NONMENU_CHANGESIZE          40003
#define IDM_NONMENU_DELLINE             40004
#define IDM_CODEPAGE_OPENAS_UNICODE_UCS2_BE 40005
#define IDM_CODEPAGE_SAVEIN_UNICODE_UCS2_BE 40006
#define IDM_SEARCH_FINDOTHER            40007
#define IDM_SEARCH_GOTOLINE             40008
#define IDM_EDIT_INSERTCHAR             40009
#define IDM_FILE_PRINT                  40010
#define IDM_FILE_PAGESETUP              40011
#define IDM_FILE_CREATENEW              40012
#define IDM_SETTINGS_NOMULTIOPEN        40013
#define IDM_CODEPAGE_NEWLINE_WIN        40014
#define IDM_CODEPAGE_NEWLINE_UNIX       40015
#define IDM_FILE_NEW                    40016
#define IDM_FILE_OPEN                   40017
#define IDM_FILE_SAVE                   40018
#define IDM_FILE_SAVEAS                 40019
#define IDM_FILE_EXIT                   40020
#define IDM_EDIT_UNDO                   40021
#define IDM_EDIT_WRAP                   40022
#define IDM_EDIT_CUT                    40023
#define IDM_EDIT_COPY                   40024
#define IDM_EDIT_PASTE                  40025
#define IDM_SEARCH_FIND                 40026
#define IDM_SEARCH_REPLACE              40027
#define IDM_SEARCH_FINDNEXT             40028
#define IDM_HELP_ABOUT                  40029
#define IDM_EDIT_SELECTALL              40030
#define IDM_EDIT_REDO                   40031
#define IDM_EDIT_CLEAR                  40032
#define IDM_EDIT_KEEPSPACE              40033
#define IDM_FILE_REOPEN                 40034
#define IDM_CODEPAGE_OPENAS_ANSI        40035
#define IDM_CODEPAGE_OPENAS_OEM         40036
#define IDM_CODEPAGE_OPENAS_KOI         40037
#define IDM_CODEPAGE_OPENAS             40038
#define IDM_CODEPAGE_SAVEIN_ANSI        40039
#define IDM_CODEPAGE_SAVEIN_OEM         40040
#define IDM_CODEPAGE_SAVEIN_KOI         40041
#define IDM_CODEPAGE_SAVEIN             40042
#define IDM_CODEPAGE_OPENAS_UNICODE_UCS2_LE 40043
#define IDM_CODEPAGE_OPENAS_UNICODE_UTF8 40044
#define IDM_CODEPAGE_SAVEIN_UNICODE_UCS2_LE 40045
#define IDM_CODEPAGE_SAVEIN_UNICODE_UTF8 40046
#define IDM_SETTINGS_ASIAN              40047
#define IDM_NONMENU_TAB                 40048
#define IDM_NONMENU_SHIFTTAB            40049
#define IDM_NONMENU_SPACE               40050
#define IDM_NONMENU_SHIFTSPACE          40051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40048
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
