//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by shellext.rc
//
#define IDR_APPSHELLEXT                 101
#define IDS_OPEN_WITH                   101
#define IDS_ERROR                       102
#define IDS_NO_PROG                     103
#define IDS_OPEN_WITH_2                 104
#define IDI_PROGRAM                     201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
