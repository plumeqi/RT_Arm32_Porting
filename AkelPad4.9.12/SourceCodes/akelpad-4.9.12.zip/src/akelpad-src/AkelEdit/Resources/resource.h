//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AkelEdit.rc
//

#define IDC_AEMARGIN                    900
#define IDC_AEHAND                      901
#define IDC_AEMCENTERALL                902
#define IDC_AEMCENTERLEFTRIGHT          903
#define IDC_AEMCENTERTOPBOTTOM          904
#define IDC_AEMLEFT                     905
#define IDC_AEMLEFTTOP                  906
#define IDC_AEMTOP                      907
#define IDC_AEMRIGHTTOP                 908
#define IDC_AEMRIGHT                    909
#define IDC_AEMRIGHTBOTTOM              910
#define IDC_AEMBOTTOM                   911
#define IDC_AEMLEFTBOTTOM               912
#define IDB_BITMAP_MCENTERALL           920
#define IDB_BITMAP_MCENTERLEFTRIGHT     921
#define IDB_BITMAP_MCENTERTOPBOTTOM     922

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
