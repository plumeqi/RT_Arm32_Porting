//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Sessions.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDI_ICON_FILE                   102
#define IDI_ICON_FOLDER                 103
#define IDC_CURSOR_DRAGMOVE             201
#define IDD_SESSIONS                    1001
#define IDD_DOCK                        1002
#define IDD_INPUTBOX                    1003
#define IDD_ITEMEDIT                    1004
#define IDD_SETTINGS                    1005
#define IDC_TITLETEXT                   1101
#define IDC_CLOSE                       1102
#define IDC_SESSION_ACTION              1103
#define IDC_SESSION_LIST                1201
#define IDC_ITEMS_LIST                  1202
#define IDC_GROUP_SESSION               1203
#define IDC_SESSION_OPEN                1204
#define IDC_SESSION_CLOSE               1205
#define IDC_SESSION_NAME                1206
#define IDC_SESSION_SAVE                1207
#define IDC_SESSION_EDIT                1208
#define IDC_SESSION_COPY                1209
#define IDC_SESSION_RENAME              1210
#define IDC_SESSION_DELETE              1211
#define IDC_SETTINGS                    1212
#define IDC_ITEM_OPEN                   1301
#define IDC_ITEM_CLOSE                  1302
#define IDC_ITEM_ADDCURFILE             1303
#define IDC_ITEM_ADDFILES               1304
#define IDC_ITEM_ADDDIR                 1305
#define IDC_ITEM_RENAME                 1306
#define IDC_ITEM_MOVEUP                 1307
#define IDC_ITEM_MOVEDOWN               1308
#define IDC_ITEM_DELETE                 1309
#define IDC_ITEM_DELETEOLD              1310
#define IDC_INPUTBOX_LABEL              1311
#define IDC_INPUTBOX_EDIT               1312
#define IDC_ITEMNAME_LABEL              1351
#define IDC_ITEMNAME                    1352
#define IDC_ITEMFILE_LABEL              1353
#define IDC_ITEMFILE                    1354
#define IDC_SETTINGS_SAVESESSIONS_GROUP 1401
#define IDC_SETTINGS_SAVESESSIONS_PROGRAMDIR 1402
#define IDC_SETTINGS_SAVESESSIONS_APPDATADIR 1403
#define IDC_SETTINGS_SESSION_GROUP      1404
#define IDC_SETTINGS_OPENNAME           1405
#define IDC_SETTINGS_OPENONSTART        1406
#define IDC_SETTINGS_SAVEONEXIT         1407
#define IDC_SETTINGS_SAVENAME           1408
#define IDC_SETTINGS_SHOWPATH           1409
#define IDC_SETTINGS_SAVERELATIVE       1410
#define IDC_SETTINGS_SYSTEMFONT         1411
#define IDC_SETTINGS_CODERTHEME         1412
#define IDC_SETTINGS_DLGTYPE_GROUP      1413
#define IDC_SETTINGS_DLGTYPE_MODAL      1414
#define IDC_SETTINGS_DLGTYPE_MODELESS   1415
#define IDC_SETTINGS_DLGTYPE_DOCKABLE   1416
#define IDC_SETTINGS_DOCKAUTOLOAD       1417
#define IDC_SETTINGS_SAVEDATA_GROUP     1418
#define IDC_SETTINGS_SAVEACTIVE         1419
#define IDC_SETTINGS_SAVECODEPAGE       1420
#define IDC_SETTINGS_SAVESELECTION      1421
#define IDC_SETTINGS_SAVEWORDWRAP       1422
#define IDC_SETTINGS_SAVEREADONLY       1423
#define IDC_SETTINGS_SAVEOVERTYPE       1424
#define IDC_SETTINGS_SAVEBOOKMARKS      1425
#define IDC_SETTINGS_SAVEALIAS          1426
#define IDC_SETTINGS_SAVEFOLDS          1427
#define IDC_SETTINGS_SAVEMARKS          1428
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
