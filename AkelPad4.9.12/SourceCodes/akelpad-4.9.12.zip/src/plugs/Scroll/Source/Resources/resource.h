//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Scroll.rc
//
#define IDI_ICON_00                     100
#define IDI_ICON_01                     101
#define IDI_ICON_02                     102
#define IDI_ICON_03                     103
#define IDI_ICON_04                     104
#define IDI_ICON_05                     105
#define IDI_ICON_06                     106
#define IDD_SYNCHORZ_SETUP              1001
#define IDD_SYNCVERT_SETUP              1002
#define IDD_AUTOSCROLL_SETUP            1003
#define IDD_NOSCROLL_SETUP              1004
#define IDD_ALIGNCARET_SETUP            1005
#define IDD_AUTOFOCUS_SETUP             1006
#define IDC_AUTOSCROLL_TITLE            1101
#define IDC_AUTOSCROLL_AUTOSTEP_GROUP   1102
#define IDC_AUTOSCROLL_STEPTIME_EDIT    1103
#define IDC_AUTOSCROLL_STEPTIME_SPIN    1104
#define IDC_AUTOSCROLL_STEPTIME_LABEL   1105
#define IDC_AUTOSCROLL_STEPWIDTH_EDIT   1106
#define IDC_AUTOSCROLL_STEPWIDTH_LABEL  1107
#define IDC_AUTOSCROLL_STEPWIDTH_SPIN   1108
#define IDC_NOSCROLL_TITLE              1201
#define IDC_NOSCROLL_GROUP              1202
#define IDC_NOSCROLL_UNDO               1203
#define IDC_NOSCROLL_REDO               1204
#define IDC_NOSCROLL_SELECTALL          1205
#define IDC_SYNCHORZ_TITLE              1301
#define IDC_SYNCHORZ_GROUP              1302
#define IDC_SYNCHORZ_MDI                1303
#define IDC_SYNCHORZ_CLONE              1304
#define IDC_SYNCVERT_TITLE              1351
#define IDC_SYNCVERT_GROUP              1352
#define IDC_SYNCVERT_MDI                1353
#define IDC_SYNCVERT_CLONE              1354
#define IDC_AUTOFOCUS_TITLE             1401
#define IDC_AUTOFOCUS_GROUP             1402
#define IDC_AUTOFOCUS_FOCUSBACKGROUND   1403
#define IDC_AUTOFOCUS_SCROLLBACKGROUND  1404
#define IDC_AUTOFOCUS_MOVESCROLLBAR     1405
#define IDC_AUTOFOCUS_MOVESCROLLBAR_INVERT 1406
#define IDC_AUTOFOCUS_MOVEWITHSHIFT     1407
#define IDC_AUTOFOCUS_MOVEWITHSHIFT_INVERT 1408
#define IDC_AUTOFOCUS_SWITCHTAB         1409
#define IDC_AUTOFOCUS_SWITCHTAB_INVERT  1410
#define IDC_AUTOFOCUS_SWITCHTAB_WITHSPIN 1411
#define IDC_ALIGNCARET_TITLE            1501
#define IDC_ALIGNCARET_GROUP            1502
#define IDC_ALIGNCARET_OFFSETX_EDIT     1503
#define IDC_ALIGNCARET_OFFSETX_SPIN     1504
#define IDC_ALIGNCARET_OFFSETX_LABEL    1505
#define IDC_ALIGNCARET_OFFSETY_EDIT     1506
#define IDC_ALIGNCARET_OFFSETY_SPIN     1507
#define IDC_ALIGNCARET_OFFSETY_LABEL    1508
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
