
#define IDC_STATIC                      -1
#define IDD_WORKBAR                     102
#define IDI_VOLUME                      103
#define IDI_RATE                        104
#define IDC_VOICE                       1001
#define IDC_APPLY                       1002
#define IDC_PLAY                        1005
#define IDC_VOLUME                      1006
#define IDC_RATE                        1007
#define IDC_PLAY2FILE                   1008
#define IDC_OUTPUT                      1009
