//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Clipboard.rc
//
#define IDI_ICON_PLUGIN                        101
#define IDD_CAPTURE                            1001
#define IDD_SETUP                              1002
#define IDC_TITLETEXT                          1101
#define IDC_CAPTURE                            1102
#define IDC_CAPTURE_CLOSE                      1103
#define IDC_SETUP_CAPTURE_TITLE                1201
#define IDC_SETUP_CAPTURE_SEPARATOR_LABEL      1202
#define IDC_SETUP_CAPTURE_SEPARATOR            1203
#define IDC_SETUP_CAPTURE_SEPARATOR_LEGEND     1204
#define IDC_SETUP_PASTESERIAL_TITLE            1205
#define IDC_SETUP_PASTESERIAL_GROUP            1301
#define IDC_SETUP_PASTESERIAL_DELIMSKIP_LABEL  1302
#define IDC_SETUP_PASTESERIAL_DELIMSKIP        1303
#define IDC_SETUP_PASTESERIAL_DELIMASTAB_LABEL 1304
#define IDC_SETUP_PASTESERIAL_DELIMASTAB       1305
#define IDC_SETUP_PASTESERIAL_DELIMASIS_LABEL  1306
#define IDC_SETUP_PASTESERIAL_DELIMASIS        1307
#define IDM_SETUP                              2001
#define IDC_STATIC                             -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
