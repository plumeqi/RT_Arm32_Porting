#ifndef _settings_dlg_h_
#define _settings_dlg_h_
//---------------------------------------------------------------------------
#include "base.h"
/*
#ifndef INT_PTR
  #define INT_PTR int
#endif
  */

INT_PTR CALLBACK SettingsDlgProc(HWND, UINT, WPARAM, LPARAM);

//---------------------------------------------------------------------------
#endif
