#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDI_XBRACKETS                           100
#define IDD_SETTINGS                            101
#define IDC_CH_BRACKETS_AUTOCOMPLETE            1001
#define IDC_CH_BRACKETS_HIGHLIGHT               1002
#define IDC_CH_BRACKETS_HIGHLIGHT_VISIBLEAREA   1003
#define IDC_BT_OK                               1004
#define IDC_BT_CANCEL                           1005
#define IDC_BT_BRACKETCOLOR                     1006
#define IDC_CH_BRACKETCOLOR                     1007
#define IDC_CH_BRACKETS_RIGHTEXISTS_OK          1008
#define IDC_ST_PLUGINSTATE                      1009
#define IDC_CH_BRACKETS_DODOUBLEQUOTE           1010
#define IDC_CH_BRACKETS_DOSINGLEQUOTE           1011
#define IDC_CH_BRACKETS_DOTAG                   1012
#define IDC_CH_BRACKETS_DOTAGIF                 1013
#define IDC_ED_BRACKETS_DOTAGIF                 1014
#define IDC_CH_BRACKETS_DOTAG2                  1015
#define IDC_CH_BRACKETS_SKIPESCAPED1            1016
#define IDC_ED_BRACKETS_SKIPESCAPED1            1017 
#define IDC_ST_BRACKETS_SKIPESCAPED1            1018
#define IDC_CH_BRACKETS_SKIPCOMMENT1            1019
#define IDC_ED_BRACKETS_SKIPCOMMENT1            1020
#define IDC_ST_BRACKETS_SKIPCOMMENT1            1021
#define IDC_BT_BKGNDCOLOR                       1022
#define IDC_CH_BKGNDCOLOR                       1023
