/**
 *		Templates for AkelPad
 *		Panych Y.W. aka FeyFre (c) 2010-2014 (panych.y@gmail.com)
 *
 *		This piece of software is distributed under BSD license.
 *		AkelPad is property of its copyright holders.
 */
#ifndef __RESOURCE_H__
#define __RESOURCE_H__

#define IDD_TEMPLATE                    101
#define IDC_TREE                        1000
#define IDC_EDIT                        1001
#define IDC_INSERT                      1002
#define IDC_REMMARKER                   1003

#endif //__RESOURCE_H__
