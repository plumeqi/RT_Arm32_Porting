/**CARET**/
#include <stdio.h>
#include <tchar.h>

int main(int argc, TCHAR* argv[])
{
	/**CARET**/
	printf("Hello, World!");
	return 0;
}