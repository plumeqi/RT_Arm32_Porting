#ifndef _qsearch_settings_dlg_h_
#define _qsearch_settings_dlg_h_
//---------------------------------------------------------------------------
#include <windows.h>
#include "resource.h"

INT_PTR CALLBACK QSFndAllSettDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

//---------------------------------------------------------------------------
#endif
