//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ContextMenu.rc
//
#define IDI_ICON_FAVADD                 100
#define IDI_ICON_FAVMANAGE              101
#define IDI_ICON_OPEN                   102
#define IDI_ICON_MOVEUP                 103
#define IDI_ICON_MOVEDOWN               104
#define IDI_ICON_SORT                   105
#define IDI_ICON_DELETE                 106
#define IDI_ICON_DELETEOLD              107
#define IDI_ICON_EDIT                   108
#define IDI_ICON_HOLLOW                 109
#define IDD_CONTEXTA                    1001
#define IDD_CONTEXTW                    1002
#define IDD_CONTEXT                     1002
#define IDC_MENUTYPE                    1101
#define IDC_MENUENABLE                  1102
#define IDC_MENUHIDE                    1103
#define IDC_MENUTEXT                    1104
#define IDC_MENUSHOW                    1105
#define IDD_FAVLIST                     1201
#define IDD_FAVEDIT                     1202
#define IDC_ITEM_LIST                   1301
#define IDC_ITEM_STATS                  1302
#define IDC_SEARCH                      1303
#define IDC_ITEM_OPEN                   1304
#define IDC_ITEM_MOVEUP                 1305
#define IDC_ITEM_MOVEDOWN               1306
#define IDC_ITEM_SORT                   1307
#define IDC_ITEM_DELETE                 1308
#define IDC_ITEM_DELETEOLD              1309
#define IDC_ITEM_EDIT                   1310
#define IDC_SHOWFILE                    1311
#define IDC_TOOLBAR                     1312
#define IDC_INPUTBOX_LABEL              1401
#define IDC_FAVNAME_LABEL               1401
#define IDC_INPUTBOX_EDIT               1402
#define IDC_FAVNAME                     1402
#define IDC_FAVFILE                     1403
#define IDC_FAVFILE_LABEL               1404
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13002
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
