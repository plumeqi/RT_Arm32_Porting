#ifndef _smart_sel_h_
#define _smart_sel_h_
//---------------------------------------------------------------------------

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <richedit.h>

#include "AkelEdit.h"
#include "AkelDLL.h"

//---------------------------------------------------------------------------
#endif
