//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Explorer.rc
//
#define IDI_ICON_PLUGIN                 101
#define IDI_ICON_FILTERNONE             102
#define IDI_ICON_FILTERINCL             103
#define IDI_ICON_FILTEREXCL             104
#define IDD_EXPLORER                    1001
#define IDD_SETUP                       1002
#define IDD_INPUTBOX                    1003
#define IDC_TITLETEXT                   1101
#define IDC_CLOSE                       1102
#define IDC_BROWSE_PATH                 1103
#define IDC_BROWSE_TREE                 1104
#define IDC_BROWSE_FILTERTYPE           1105
#define IDC_BROWSE_FILTERCOMBO          1106
#define IDC_BROWSE_FILTERITEM           1107
#define IDC_SETUP_ROOT_GROUP            1201
#define IDC_SETUP_ROOTDIRECTORY_EDIT    1202
#define IDC_SETUP_ROOTDIRECTORY_BROWSE  1203
#define IDC_SETUP_ROOTMYCOMPUTER        1204
#define IDC_SETUP_SHOWHIDDEN            1205
#define IDC_SETUP_AUTOFIND              1206
#define IDC_SETUP_SINGLECLICK           1207
#define IDC_SETUP_SETSAVELOCATION       1208
#define IDC_INPUTBOX_LABEL              1301
#define IDC_INPUTBOX_EDIT               1302
#define IDM_SETUP                       2001
#define IDM_RENAME                      2002
#define IDM_FINDDOCUMENT                2003
#define IDM_REFRESH                     2004
#define IDM_CREATEDIR                   2005
#define IDM_CREATEFILE                  2006
#define IDM_FILTERNONE                  2101
#define IDM_FILTERINCLUDE               2102
#define IDM_FILTEREXCLUDE               2103
#define IDM_FILTERITEMADD               2104
#define IDM_FILTERITEMMOVEUP            2105
#define IDM_FILTERITEMMOVEDOWN          2106
#define IDM_FILTERITEMREMOVE            2107
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13001
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
