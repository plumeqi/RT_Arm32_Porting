//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Version.rc
//
#define IDS_NOASPELL                    100
#define IDS_NOMISSSPELL                 101
#define IDS_NOVARIANT                   102
#define IDD_SETTINGS                    102
#define IDD_RAPIDCHECK                  103
#define IDC_DEFDICT                     1000
#define IDC_DEFJAR                      1002
#define IDC_SUGLIST                     1003
#define IDC_MISSSPELL                   1004
#define IDC_CANCELALL                   1007
#define IDC_SHOWNOTICE                  1008
#define IDC_ORIGINAL                    1009
#define IDC_HIGHLIGHT                   1010
#define IDC_COLOR                       1011
#define IDC_STYLE                       1012
#define IDC_CORE                        1013
#define IDC_BROWSE                      1014
#define IDC_WHITELIST                   1015
#define IDC_PROBE                       1016
#define IDC_MEM                         1017
#define IDC_NOBGEDIT                    1018
#define IDC_NOBG                        1019
#define IDC_NOBGADD                     1020
#define IDC_NOBGREM                     1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
