AkelPad
=======

Host AkelPad projects full code, original site is http://akelpad.sourceforge.net/

![image](sample.png)

![image](https://a.fsdn.com/con/app/proj/akelpad/screenshots/311643.jpg/max/max/1)

![image](https://a.fsdn.com/con/app/proj/akelpad/screenshots/251378.jpg/max/max/1)
