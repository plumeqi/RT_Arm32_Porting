// encoding: UTF-8
// mp_hu_hu.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


