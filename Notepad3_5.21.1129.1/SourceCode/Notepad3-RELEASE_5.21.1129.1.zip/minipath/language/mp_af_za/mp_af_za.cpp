// encoding: UTF-8
// mp_af_za.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


