// encoding: UTF-8
// np3_sv_se.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


