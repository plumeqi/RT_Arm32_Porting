// encoding: UTF-8
// np3_pl_pl.cpp: Definiert die exportierten Funktionen für die DLL-Anwendung.
//

#include "stdafx.h"


