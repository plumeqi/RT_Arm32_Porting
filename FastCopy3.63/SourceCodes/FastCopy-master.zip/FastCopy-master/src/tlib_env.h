#define USE_XXHASH
