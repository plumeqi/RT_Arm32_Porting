//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by install.rc
//
#define IDS_MKDIR                       1
#define IDS_RMDIR                       2
#define IDS_SETUPCOMPLETE               3
#define IDS_UNINSTFIN                   4
#define IDS_UNINSTSHEXTFIN              5
#define IDS_NOTCREATEDIR                6
#define IDS_NOTCREATEFILE               7
#define IDS_START                       8
#define IDS_REPLACECOMPLETE             9
#define IDS_DELAYSETUPCOMPLETE          10
#define IDS_ADMINCHANGE                 11
#define IDS_LOWINTEGRITY                12
#define IDS_EXTRACT                     13
#define IDS_EXTRACTDIR                  14
#define IDS_HELPURL                     15
#define IDS_URL                         16
#define IDS_SUPPORTBBS                  17
#define IDS_WOW64                       18
#define IDS_SELECTPATH                  50
#define INSTALL_SHEET                   101
#define SETUP_ICON                      104
#define MKDIR_BUTTON                    110
#define RMDIR_BUTTON                    111
#define X86_RADIO                       112
#define X64_RADIO                       113
#define INSTALL_DIALOG                  149
#define INPUT_DIALOG                    150
#define LAUNCH_DIALOG                   151
#define UNINSTALL_SHEET                 152
#define INSTALL_STATIC                  1133
#define MESSAGE_STATIC                  1134
#define FILE_EDIT                       1135
#define FILE_BUTTON                     1136
#define DESKTOP_CHECK                   1138
#define DEFAULT_BTN                     1138
#define PROGRAM_CHECK                   1139
#define INPUT_EDIT                      1140
#define SETUP_RADIO                     1145
#define UNINSTALL_RADIO                 1146
#define RUNAS_BUTTON                    1155
#define EXTRACT_BTN                     1156
#define EXTRACT_EDIT                    1157
#define INST_STATIC                     1158
#define IDC_MODE                        1159
#define SETUP_GRP                       1160

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         30034
#define _APS_NEXT_CONTROL_VALUE         1161
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
